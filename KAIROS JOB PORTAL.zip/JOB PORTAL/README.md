# KAIROS Job Portal

**"Luck meets opportunity at the perfect moment."**

A full-stack MERN job marketplace with a three-tier professional ecosystem — Seekers, Recruiters, and Administrators — built with a premium dark/gold visual language.

---

## Project Structure

```
KAIROS/
├── server/                  # Express.js + MongoDB backend
│   ├── config/db.js
│   ├── controllers/         # Business logic
│   ├── middleware/          # Auth guard + file upload
│   ├── models/              # Mongoose schemas
│   ├── routes/              # API endpoints
│   ├── utils/emailService.js
│   └── server.js
└── client/                  # React + Vite + Tailwind frontend
    └── src/
        ├── components/      # Navbar, Footer, JobCard, etc.
        ├── context/         # AuthContext, ThemeContext
        ├── pages/           # All page views
        ├── routes/          # ProtectedRoute, AdminRoute, GuestRoute
        └── services/api.js  # Axios API wrappers
```

---

## Environment Setup

### Backend — `server/.env`

```env
PORT=5000
NODE_ENV=development
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_super_secure_jwt_secret_here
JWT_EXPIRE=7d
CLIENT_URL=http://localhost:5173

# SMTP (use Brevo, Gmail App Passwords, or any SMTP provider)
SMTP_HOST=smtp-relay.brevo.com
SMTP_PORT=587
SMTP_USER=your_smtp_login
SMTP_PASS=your_smtp_password
MAIL_FROM=noreply@kairos.com
```

### Frontend — `client/.env`

```env
VITE_API_URL=http://localhost:5000/api
```

---

## Running the Project

### 1. Install & Start Backend

```bash
cd server
npm install
node server.js
# or: npx nodemon server.js (auto-restart on changes)
```

### 2. Install & Start Frontend

```bash
cd client
npm install
npm run dev
```

The app runs at **http://localhost:5173**

---

## Seeding an Admin Account

The admin must be created directly in MongoDB (no public registration for admins):

```js
// In MongoDB Compass or Atlas shell:
db.users.insertOne({
  name: "KAIROS Admin",
  email: "admin@kairos.com",
  password: "$2a$12$...", // bcrypt-hashed password
  role: "admin",
  createdAt: new Date()
})
```

Or use a seed script:
```bash
# From the server directory
node -e "
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();
mongoose.connect(process.env.MONGO_URI).then(async () => {
  const User = require('./models/User');
  const hash = await bcrypt.hash('admin123', 12);
  await User.create({ name: 'Admin', email: 'admin@kairos.com', password: hash, role: 'admin' });
  console.log('Admin created: admin@kairos.com / admin123');
  process.exit();
});
"
```

Access admin at: **http://localhost:5173/admin/login**

---

## Key Fixes in This Version

| Issue | Fix |
|---|---|
| `AdminPanel` calling `applicationsAPI.getAll()` that didn't exist | Added `/applications/all` route + `getAllApplications` controller |
| Admin stats referencing `totalUsers` but backend never returned it | Backend now computes and returns `totalUsers = seekers + recruiters` |
| `RecruiterDashboard` — "View Resume" button did nothing | Now renders a clickable link to the actual PDF served from `/uploads/` |
| `JobDetail` referenced `isSeeker` but it wasn't destructured from `useAuth` | Fixed destructuring; `isSeeker` exported from `AuthContext` |
| `verifyJob` in admin didn't toggle — just sent a PATCH with no logic | Backend now toggles `job.isVerified` and returns the updated job |
| No dedicated `PostJob` page — jobs were routed to `JobDetail` | New dedicated `PostJob.jsx` page for create and edit flows |
| `applicationsAPI.updateStatus` didn't exist | Added to `api.js` with correct endpoint |
| Profile page Education/Experience tabs rendered blank | Fully implemented with add/edit/remove functionality |
| Recruiter "Post a Job" link navigated to non-existent route | Now routes to `/recruiter/post-job` → `PostJob.jsx` |
| `AdminPanel` delete logic imported `jobsAPI` dynamically | Cleaned up — proper imports at top of file |
| Comments cluttered all files | All unnecessary comments removed throughout |

---

## User Workflows

### Seeker Flow
1. Register at `/register` (default role)
2. Upload resume at `/resume`
3. Build profile at `/profile` (skills, education, experience)
4. Browse jobs at `/jobs`
5. Click any job → Express Interest → Submit application
6. Track status updates at `/dashboard`

### Recruiter Flow
1. Register at `/register?role=recruiter`
2. Post a job at `/recruiter/post-job`
3. Job enters **pending** state until admin verifies
4. Once live, applicants can apply
5. Manage pipeline at `/recruiter/dashboard`
6. View candidate resumes and update application status

### Admin Flow
1. Access admin portal at `/admin/login`
2. Overview dashboard shows platform stats
3. Verify/unverify job listings
4. Manage all applications and update statuses
5. Delete users or spam listings

---

## Email Notifications

Emails are triggered automatically:
- **On Application Submitted** → seeker gets confirmation, recruiter gets alert
- **On Status Change** (shortlisted, under-review, rejected) → seeker receives a branded HTML email

Email delivery requires a configured SMTP provider in `.env`. Recommended: **Brevo** (free tier, 300 emails/day).
