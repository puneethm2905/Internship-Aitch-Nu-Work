import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import Navbar from '../components/Navbar';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) {
      toast.error('Please fill in all fields');
      return;
    }

    setLoading(true);
    try {
      const res = await authAPI.login(form);
      const { token, user } = res.data;
      login(token, user);
      toast.success(`Welcome back, ${user.name.split(' ')[0]}!`);

      switch (user.role) {
        case 'admin':
          navigate('/admin');
          break;
        case 'recruiter':
          navigate('/recruiter/dashboard');
          break;
        default:
          navigate('/dashboard');
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-shell">
      <Navbar />
      <div className="min-h-screen flex items-center justify-center px-4 pt-16">
        <div className="w-full max-w-md">
          <div className="auth-header text-center mb-6">
            <div className="auth-logo mx-auto mb-4">K</div>
            <h1 className="auth-title">Welcome Back</h1>
            <p className="auth-subtitle italic">Sign in to your KAIROS account</p>
          </div>

          <div className="card p-8 shadow-xl">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="form-label">Email Address</label>
                <input
                  name="email"
                  type="email"
                  value={form.email}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="john@example.com"
                  required
                />
              </div>
              <div>
                <label className="form-label">Password</label>
                <input
                  name="password"
                  type="password"
                  value={form.password}
                  onChange={handleChange}
                  className="input-field"
                  placeholder="Your password"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className={`btn-primary w-full mt-2 ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
              >
                {loading ? 'Verifying...' : 'Sign In'}
              </button>
            </form>

            <div className="mt-6 text-center text-sm text-muted">
              Don't have an account?{' '}
              <Link to="/register" className="font-bold accent-link hover:underline">
                Register now
              </Link>
            </div>
          </div>

          <div className="mt-6 p-4 bg-accent/5 rounded-xl border border-accent/10">
            <p className="text-center text-xs text-muted">
              Platform administrator?{' '}
              <Link to="/admin/login" className="accent-link font-bold hover:underline">
                Access Admin Terminal
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
