import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { jobsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';

const TYPES = ['Full-Time', 'Part-Time', 'Remote', 'Hybrid', 'Internship', 'Contract'];
const CATEGORIES = ['Technology', 'Management', 'Marketing', 'Finance', 'Design', 'Healthcare', 'Education', 'Other'];
const EXPERIENCES = ['0-1 years', '1-3 years', '3-5 years', '5+ years'];

const emptyForm = {
  title: '',
  company: '',
  location: '',
  type: 'Full-Time',
  category: 'Technology',
  salary: '',
  description: '',
  requirements: '',
  skills: '',
  experience: '0-1 years',
  deadline: '',
};

const PostJob = () => {
  const { id } = useParams();
  const isEditing = Boolean(id);
  const navigate = useNavigate();
  const { user } = useAuth();

  const [form, setForm] = useState({
    ...emptyForm,
    company: user?.companyDetails?.companyName || '',
  });
  const [loading, setLoading] = useState(isEditing);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (isEditing) {
      jobsAPI.getById(id)
        .then((res) => {
          const job = res.data.job;
          setForm({
            title: job.title || '',
            company: job.company || '',
            location: job.location || '',
            type: job.type || 'Full-Time',
            category: job.category || 'Technology',
            salary: job.salary || '',
            description: job.description || '',
            requirements: job.requirements?.join('\n') || '',
            skills: job.skills?.join(', ') || '',
            experience: job.experience || '0-1 years',
            deadline: job.deadline ? new Date(job.deadline).toISOString().split('T')[0] : '',
          });
        })
        .catch(() => {
          toast.error('Failed to load job data');
          navigate('/recruiter/dashboard');
        })
        .finally(() => setLoading(false));
    }
  }, [id, isEditing, navigate]);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.company || !form.location || !form.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        ...form,
        requirements: form.requirements
          ? form.requirements.split('\n').map((r) => r.trim()).filter(Boolean)
          : [],
        skills: form.skills
          ? form.skills.split(',').map((s) => s.trim()).filter(Boolean)
          : [],
        deadline: form.deadline || undefined,
      };

      if (isEditing) {
        await jobsAPI.update(id, payload);
        toast.success('Job listing updated!');
      } else {
        await jobsAPI.create(payload);
        toast.success('Job posted! It will appear on the marketplace after admin verification.');
      }

      navigate('/recruiter/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to save job listing');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="page-shell bg-gray-50/50">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-24 pb-16">
        <Link
          to="/recruiter/dashboard"
          className="text-accent text-[10px] font-black uppercase tracking-[0.2em] mb-8 inline-flex items-center gap-2 hover:-translate-x-1 transition-transform"
        >
          <Icon name="arrowLeft" size={14} /> Back to Dashboard
        </Link>

        <div className="mb-8">
          <div className="display-badge text-[10px] font-bold px-3 py-1 rounded-full mb-3 inline-flex">
            <Icon name="briefcase" size={12} className="mr-1" />
            {isEditing ? 'Edit Listing' : 'New Listing'}
          </div>
          <h1 className="font-cinzel font-black text-3xl mb-2 text-primary tracking-widest uppercase">
            {isEditing ? 'Update Job' : 'Post a Job'}
          </h1>
          <p className="text-sm text-muted">
            {isEditing
              ? 'Update the details of your job listing.'
              : 'Your listing enters a pending state and goes live after admin verification.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="card p-10 bg-white shadow-2xl rounded-2xl space-y-8">
          <Section title="Core Details">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Field label="Job Title *">
                <input name="title" value={form.title} onChange={handleChange} className="input-field" placeholder="e.g. Senior Frontend Engineer" required />
              </Field>
              <Field label="Company Name *">
                <input name="company" value={form.company} onChange={handleChange} className="input-field" placeholder="Your company name" required />
              </Field>
              <Field label="Location *">
                <input name="location" value={form.location} onChange={handleChange} className="input-field" placeholder="e.g. Bengaluru / Remote" required />
              </Field>
              <Field label="Salary Range">
                <input name="salary" value={form.salary} onChange={handleChange} className="input-field" placeholder="e.g. ₹12-18 LPA" />
              </Field>
            </div>
          </Section>

          <Section title="Classification">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Field label="Work Type *">
                <select name="type" value={form.type} onChange={handleChange} className="input-field">
                  {TYPES.map((t) => <option key={t}>{t}</option>)}
                </select>
              </Field>
              <Field label="Industry Category *">
                <select name="category" value={form.category} onChange={handleChange} className="input-field">
                  {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
                </select>
              </Field>
              <Field label="Experience Level">
                <select name="experience" value={form.experience} onChange={handleChange} className="input-field">
                  {EXPERIENCES.map((e) => <option key={e}>{e}</option>)}
                </select>
              </Field>
            </div>
          </Section>

          <Section title="Description">
            <Field label="Full Job Description *">
              <textarea
                name="description"
                value={form.description}
                onChange={handleChange}
                className="input-field min-h-[200px] resize-y"
                placeholder="Describe the role, responsibilities, and what makes this opportunity great..."
                required
              />
            </Field>
          </Section>

          <Section title="Requirements & Skills">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Field label="Requirements (one per line)">
                <textarea
                  name="requirements"
                  value={form.requirements}
                  onChange={handleChange}
                  className="input-field min-h-[120px] resize-y"
                  placeholder={"Bachelor's degree in CS\n3+ years React experience\nStrong communication skills"}
                />
              </Field>
              <Field label="Skills (comma-separated)">
                <textarea
                  name="skills"
                  value={form.skills}
                  onChange={handleChange}
                  className="input-field min-h-[120px] resize-y"
                  placeholder="React, TypeScript, Node.js, GraphQL"
                />
              </Field>
            </div>
          </Section>

          <Section title="Timeline">
            <Field label="Application Deadline">
              <input
                name="deadline"
                type="date"
                value={form.deadline}
                onChange={handleChange}
                className="input-field"
                min={new Date().toISOString().split('T')[0]}
              />
            </Field>
          </Section>

          <div className="flex gap-4 pt-4 border-t border-accent/10">
            <button
              type="submit"
              disabled={submitting}
              className={`btn-primary flex-1 py-4 font-black uppercase tracking-[0.2em] ${submitting ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {submitting
                ? isEditing ? 'Updating...' : 'Posting...'
                : isEditing ? 'Update Listing' : 'Submit for Review'}
            </button>
            <Link to="/recruiter/dashboard" className="btn-outline px-8 py-4 font-bold">
              Cancel
            </Link>
          </div>
        </form>
      </div>
      <Footer />
    </div>
  );
};

const Section = ({ title, children }) => (
  <div>
    <h2 className="font-cinzel font-bold text-sm mb-4 text-accent uppercase tracking-[0.2em] border-b border-accent/10 pb-2">
      {title}
    </h2>
    {children}
  </div>
);

const Field = ({ label, children }) => (
  <div className="space-y-2">
    <label className="text-[10px] font-black uppercase text-muted tracking-widest">{label}</label>
    {children}
  </div>
);

export default PostJob;
