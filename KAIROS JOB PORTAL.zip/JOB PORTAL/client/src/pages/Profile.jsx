import { useEffect, useRef, useState } from 'react';
import toast from 'react-hot-toast';
import { profileAPI, resumeAPI, certificatesAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';

const SKILLS_LIST = [
  'JavaScript', 'TypeScript', 'React', 'Node.js', 'Python', 'Java', 'MongoDB',
  'SQL', 'AWS', 'Docker', 'Git', 'GraphQL', 'Figma', 'Tailwind CSS', 'Next.js',
  'Vue.js', 'Django', 'PostgreSQL', 'Redis', 'Kubernetes',
];

const TABS = ['Overview', 'Education', 'Experience', 'Certificates', 'Links'];

const emptyEdu  = { institution: '', degree: '', field: '', from: '', to: '', current: false };
const emptyExp  = { title: '', company: '', location: '', from: '', to: '', current: false, description: '' };
const emptyCert = { title: '', issuer: '', issueDate: '', credentialUrl: '', fileUrl: '', filename: '', description: '' };

const API_BASE = import.meta.env.VITE_API_URL?.replace('/api', '') || 'http://localhost:5000';

const Profile = () => {
  const { user, isRecruiter } = useAuth();
  const avatarRef  = useRef();
  const certRefs   = useRef({});

  const [profile,         setProfile]         = useState(null);
  const [resume,          setResume]           = useState(null);
  const [loading,         setLoading]          = useState(true);
  const [saving,          setSaving]           = useState(false);
  const [uploadingAvatar, setUploadingAvatar]  = useState(false);
  const [uploadingCert,   setUploadingCert]    = useState({});
  const [avatarPreview,   setAvatarPreview]    = useState(null);
  const [activeTab,       setActiveTab]        = useState('Overview');

  const [form, setForm] = useState({
    name: '', phone: '', bio: '', skills: [],
    education: [], experience: [], certificates: [],
    links: { linkedin: '', github: '', portfolio: '' },
    companyName: '', companyWebsite: '', companyIndustry: '', companyDescription: '',
  });

  useEffect(() => {
    const load = async () => {
      try {
        const [profileRes, resumeRes] = await Promise.all([
          profileAPI.get(),
          isRecruiter ? Promise.resolve({ data: { resume: null } }) : resumeAPI.getMy(),
        ]);
        const p = profileRes.data.profile;
        setProfile(p);
        setResume(resumeRes.data.resume);

        if (p.user?.avatar) setAvatarPreview(`${API_BASE}${p.user.avatar}`);

        if (isRecruiter) {
          setForm((prev) => ({
            ...prev,
            name: p.user?.name || '',
            phone: p.user?.phone || '',
            companyName:        p.user?.companyDetails?.companyName  || '',
            companyWebsite:     p.user?.companyDetails?.website      || '',
            companyIndustry:    p.user?.companyDetails?.industry     || '',
            companyDescription: p.user?.companyDetails?.description  || '',
          }));
        } else {
          setForm((prev) => ({
            ...prev,
            name:         p.user?.name  || '',
            phone:        p.user?.phone || '',
            bio:          p.bio         || '',
            skills:       p.skills      || [],
            education:    p.education   || [],
            experience:   p.experience  || [],
            certificates: p.certificates|| [],
            links:        p.links       || { linkedin: '', github: '', portfolio: '' },
          }));
        }
      } catch {
        toast.error('Failed to load profile');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user, isRecruiter]);

  /* ── avatar ── */
  const handleAvatarChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    if (!['image/jpeg','image/png','image/webp'].includes(file.type)) {
      toast.error('Only JPG, PNG, or WEBP images allowed');
      return;
    }
    if (file.size > 3 * 1024 * 1024) { toast.error('Image must be under 3 MB'); return; }

    setAvatarPreview(URL.createObjectURL(file));
    setUploadingAvatar(true);
    try {
      const fd = new FormData();
      fd.append('avatar', file);
      const res = await profileAPI.uploadAvatar(fd);
      setAvatarPreview(`${API_BASE}${res.data.avatarUrl}`);
      const stored = JSON.parse(localStorage.getItem('kairos-user') || '{}');
      localStorage.setItem('kairos-user', JSON.stringify({ ...stored, avatar: res.data.avatarUrl }));
      toast.success('Profile photo updated!');
    } catch {
      toast.error('Failed to upload photo');
    } finally {
      setUploadingAvatar(false);
    }
  };

  /* ── certificate file upload ── */
  const handleCertFileChange = async (e, idx) => {
    const file = e.target.files[0];
    if (!file) return;

    const allowed = ['application/pdf','image/jpeg','image/png','image/webp'];
    if (!allowed.includes(file.type)) {
      toast.error('Only PDF or image files allowed');
      return;
    }
    if (file.size > 5 * 1024 * 1024) { toast.error('File must be under 5 MB'); return; }

    setUploadingCert((p) => ({ ...p, [idx]: true }));
    try {
      const fd = new FormData();
      fd.append('certificate', file);
      const res = await certificatesAPI.upload(fd);

      updateCert(idx, 'fileUrl',  res.data.fileUrl);
      updateCert(idx, 'filename', res.data.filename);
      toast.success('Certificate file uploaded!');
    } catch {
      toast.error('Failed to upload certificate file');
    } finally {
      setUploadingCert((p) => ({ ...p, [idx]: false }));
      e.target.value = '';
    }
  };

  const handleRemoveCertFile = async (idx) => {
    const cert = form.certificates[idx];
    if (!cert.fileUrl) return;

    const serverFilename = cert.fileUrl.split('/').pop();
    try {
      await certificatesAPI.deleteFile(serverFilename);
    } catch {
      /* ignore — remove UI state anyway */
    }
    updateCert(idx, 'fileUrl',  '');
    updateCert(idx, 'filename', '');
    toast.success('File removed');
  };

  /* ── form helpers ── */
  const handleChange      = (e)       => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));
  const handleLinkChange  = (e)       => setForm((p) => ({ ...p, links: { ...p.links, [e.target.name]: e.target.value } }));
  const toggleSkill       = (skill)   => setForm((p) => ({
    ...p,
    skills: p.skills.includes(skill) ? p.skills.filter((s) => s !== skill) : [...p.skills, skill],
  }));

  const addEdu    = ()        => setForm((p) => ({ ...p, education:    [...p.education,    { ...emptyEdu  }] }));
  const updateEdu = (i, k, v) => setForm((p) => { const a = [...p.education];    a[i] = { ...a[i], [k]: v }; return { ...p, education:    a }; });
  const removeEdu = (i)       => setForm((p) => ({ ...p, education:    p.education.filter((_,idx)=>idx!==i) }));

  const addExp    = ()        => setForm((p) => ({ ...p, experience:   [...p.experience,   { ...emptyExp  }] }));
  const updateExp = (i, k, v) => setForm((p) => { const a = [...p.experience];   a[i] = { ...a[i], [k]: v }; return { ...p, experience:   a }; });
  const removeExp = (i)       => setForm((p) => ({ ...p, experience:   p.experience.filter((_,idx)=>idx!==i) }));

  const addCert    = ()        => setForm((p) => ({ ...p, certificates: [...p.certificates, { ...emptyCert }] }));
  const updateCert = (i, k, v) => setForm((p) => { const a = [...p.certificates]; a[i] = { ...a[i], [k]: v }; return { ...p, certificates: a }; });
  const removeCert = async (i) => {
    const cert = form.certificates[i];
    if (cert.fileUrl) {
      const serverFilename = cert.fileUrl.split('/').pop();
      try { await certificatesAPI.deleteFile(serverFilename); } catch {}
    }
    setForm((p) => ({ ...p, certificates: p.certificates.filter((_,idx)=>idx!==i) }));
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (isRecruiter) {
        await profileAPI.update({
          name: form.name, phone: form.phone,
          companyDetails: {
            companyName:  form.companyName,
            website:      form.companyWebsite,
            industry:     form.companyIndustry,
            description:  form.companyDescription,
          },
        });
      } else {
        await profileAPI.update({
          name: form.name, phone: form.phone,
          bio: form.bio, skills: form.skills,
          education:    form.education,
          experience:   form.experience,
          certificates: form.certificates,
          links:        form.links,
        });
      }
      toast.success('Profile saved!');
    } catch {
      toast.error('Save failed');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <Loader />;

  const completionFields = [form.name, form.bio, form.skills.length > 0, form.education.length > 0, form.experience.length > 0, resume, avatarPreview];
  const completionPct    = Math.round((completionFields.filter(Boolean).length / completionFields.length) * 100);
  const displayTabs      = isRecruiter ? ['Overview'] : TABS;

  return (
    <div className="page-shell" style={{ background: 'var(--bg-secondary)' }}>
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-24 pb-16">

        {/* Page header */}
        <div className="mb-8">
          <h1 className="font-cinzel font-black text-3xl mb-1 text-primary tracking-widest uppercase">
            {isRecruiter ? 'Company Profile' : 'Professional Profile'}
          </h1>
          <p className="text-sm text-muted">
            {isRecruiter
              ? 'Manage your company details.'
              : 'Build your professional identity to attract the best opportunities.'}
          </p>
        </div>

        {/* Avatar + strength banner */}
        <div className="gradient-panel rounded-2xl p-6 mb-8">
          <div className="flex items-center gap-6 flex-wrap">

            {/* Avatar */}
            <div className="relative flex-shrink-0">
              <div
                className="w-20 h-20 rounded-2xl border-2 border-accent/40 overflow-hidden cursor-pointer bg-primary flex items-center justify-center group"
                onClick={() => avatarRef.current?.click()}
                title="Click to change photo"
              >
                {uploadingAvatar ? (
                  <span className="w-6 h-6 border-2 border-accent/30 border-t-accent rounded-full animate-spin" />
                ) : avatarPreview ? (
                  <img src={avatarPreview} alt="Avatar" className="w-full h-full object-cover" />
                ) : (
                  <span className="font-cinzel font-black text-2xl text-accent">{user?.name?.charAt(0)}</span>
                )}
                <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-2xl">
                  <Icon name="camera" size={22} className="text-white" />
                </div>
              </div>
              <input ref={avatarRef} type="file" accept="image/jpeg,image/png,image/webp" className="hidden" onChange={handleAvatarChange} />
              <button
                type="button"
                onClick={() => avatarRef.current?.click()}
                className="absolute -bottom-2 -right-2 w-7 h-7 bg-accent text-primary rounded-full flex items-center justify-center shadow-lg border-2 border-white"
              >
                <Icon name="camera" size={12} />
              </button>
            </div>

            {/* Name + progress */}
            <div className="flex-1 min-w-[180px]">
              <p className="font-bold text-primary text-lg">{user?.name}</p>
              <p className="text-xs text-accent font-bold uppercase tracking-widest mb-3">{user?.role}</p>
              {!isRecruiter && (
                <>
                  <div className="flex justify-between mb-1">
                    <p className="text-[10px] font-black uppercase text-muted tracking-widest">Profile Strength</p>
                    <span className="text-[10px] font-black text-accent">{completionPct}%</span>
                  </div>
                  <progress value={completionPct} max={100} className="profile-progress w-full" />
                  <p className="text-[10px] text-muted mt-1">
                    {completionPct >= 80 ? '✓ Strong profile' : 'Add more details to improve visibility'}
                  </p>
                </>
              )}
            </div>

            {/* Photo hint */}
            <div className="text-[10px] text-muted text-center">
              <p className="font-black mb-1 uppercase tracking-widest">Photo</p>
              <p>JPG, PNG, WEBP</p>
              <p>Max 3 MB</p>
            </div>
          </div>
        </div>

        {/* Main form card */}
        <form onSubmit={handleSave} className="card bg-white shadow-xl rounded-2xl overflow-hidden">

          {/* Tabs */}
          {!isRecruiter && (
            <div className="flex overflow-x-auto border-b border-accent/10 px-2 pt-2">
              {displayTabs.map((tab) => (
                <button
                  key={tab} type="button" onClick={() => setActiveTab(tab)}
                  className={`px-5 py-3 text-[10px] font-black uppercase tracking-[0.2em] whitespace-nowrap transition-all ${
                    activeTab === tab ? 'text-accent border-b-2 border-accent' : 'text-muted hover:text-primary'
                  }`}
                >
                  {tab}
                </button>
              ))}
            </div>
          )}

          <div className="p-8 space-y-8">

            {/* ── OVERVIEW ── */}
            {(activeTab === 'Overview' || isRecruiter) && (
              <section className="space-y-6">
                <SectionTitle title={isRecruiter ? 'Company Identity' : 'Personal Details'} />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <Field label="Full Name">
                    <input name="name" value={form.name} onChange={handleChange} className="input-field" placeholder="Your full name" />
                  </Field>
                  <Field label="Phone">
                    <input name="phone" value={form.phone} onChange={handleChange} className="input-field" placeholder="+91 98765 43210" />
                  </Field>
                </div>

                {isRecruiter ? (
                  <div className="space-y-5">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <Field label="Company Name">
                        <input name="companyName" value={form.companyName} onChange={handleChange} className="input-field" placeholder="Nexus Technologies" />
                      </Field>
                      <Field label="Website">
                        <input name="companyWebsite" value={form.companyWebsite} onChange={handleChange} className="input-field" placeholder="https://nexus.com" />
                      </Field>
                      <Field label="Industry">
                        <input name="companyIndustry" value={form.companyIndustry} onChange={handleChange} className="input-field" placeholder="Technology" />
                      </Field>
                    </div>
                    <Field label="Company Description">
                      <textarea name="companyDescription" value={form.companyDescription} onChange={handleChange} className="input-field min-h-[100px] resize-y" placeholder="Tell candidates about your company..." />
                    </Field>
                  </div>
                ) : (
                  <>
                    <Field label="Professional Bio">
                      <textarea name="bio" value={form.bio} onChange={handleChange} className="input-field min-h-[100px] resize-y" placeholder="Describe your background, what drives you, and what you're looking for..." />
                    </Field>
                    <div>
                      <Field label="Technical Stack (click to select)">
                        <div className="flex flex-wrap gap-2 mt-2">
                          {SKILLS_LIST.map((skill) => (
                            <button
                              key={skill} type="button" onClick={() => toggleSkill(skill)}
                              className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${
                                form.skills.includes(skill)
                                  ? 'bg-accent text-primary border-accent'
                                  : 'border-accent/20 text-muted hover:border-accent/50'
                              }`}
                            >{skill}</button>
                          ))}
                        </div>
                      </Field>
                      {form.skills.length > 0 && (
                        <p className="text-[10px] text-muted mt-2">{form.skills.length} skill{form.skills.length > 1 ? 's' : ''} selected</p>
                      )}
                    </div>
                  </>
                )}
              </section>
            )}

            {/* ── EDUCATION ── */}
            {activeTab === 'Education' && !isRecruiter && (
              <section>
                <div className="flex items-center justify-between mb-5">
                  <SectionTitle title="Education History" />
                  <AddBtn onClick={addEdu} />
                </div>
                {form.education.length === 0 ? (
                  <EmptyState icon="education" label="No education entries yet." onAdd={addEdu} />
                ) : (
                  <div className="space-y-5">
                    {form.education.map((edu, i) => (
                      <EntryCard key={i} onRemove={() => removeEdu(i)}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <Field label="Institution *"><input value={edu.institution} onChange={(e) => updateEdu(i,'institution',e.target.value)} className="input-field" placeholder="Harvard University" /></Field>
                          <Field label="Degree *"><input value={edu.degree} onChange={(e) => updateEdu(i,'degree',e.target.value)} className="input-field" placeholder="Bachelor of Science" /></Field>
                          <Field label="Field of Study"><input value={edu.field} onChange={(e) => updateEdu(i,'field',e.target.value)} className="input-field" placeholder="Computer Science" /></Field>
                          <div className="flex gap-3">
                            <Field label="From"><input type="date" value={edu.from?.toString().slice(0,10)||''} onChange={(e) => updateEdu(i,'from',e.target.value)} className="input-field" /></Field>
                            {!edu.current && <Field label="To"><input type="date" value={edu.to?.toString().slice(0,10)||''} onChange={(e) => updateEdu(i,'to',e.target.value)} className="input-field" /></Field>}
                          </div>
                          <div className="flex items-center gap-2 md:col-span-2">
                            <input type="checkbox" id={`edu-c-${i}`} checked={edu.current} onChange={(e) => updateEdu(i,'current',e.target.checked)} />
                            <label htmlFor={`edu-c-${i}`} className="text-xs font-bold text-muted">Currently enrolled</label>
                          </div>
                        </div>
                      </EntryCard>
                    ))}
                  </div>
                )}
              </section>
            )}

            {/* ── EXPERIENCE ── */}
            {activeTab === 'Experience' && !isRecruiter && (
              <section>
                <div className="flex items-center justify-between mb-5">
                  <SectionTitle title="Work Experience" />
                  <AddBtn onClick={addExp} />
                </div>
                {form.experience.length === 0 ? (
                  <EmptyState icon="briefcase" label="No work experience yet." onAdd={addExp} />
                ) : (
                  <div className="space-y-5">
                    {form.experience.map((exp, i) => (
                      <EntryCard key={i} onRemove={() => removeExp(i)}>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <Field label="Job Title *"><input value={exp.title} onChange={(e) => updateExp(i,'title',e.target.value)} className="input-field" placeholder="Senior Frontend Engineer" /></Field>
                          <Field label="Company *"><input value={exp.company} onChange={(e) => updateExp(i,'company',e.target.value)} className="input-field" placeholder="Nexus Technologies" /></Field>
                          <Field label="Location"><input value={exp.location} onChange={(e) => updateExp(i,'location',e.target.value)} className="input-field" placeholder="Bengaluru / Remote" /></Field>
                          <div className="flex gap-3">
                            <Field label="From"><input type="date" value={exp.from?.toString().slice(0,10)||''} onChange={(e) => updateExp(i,'from',e.target.value)} className="input-field" /></Field>
                            {!exp.current && <Field label="To"><input type="date" value={exp.to?.toString().slice(0,10)||''} onChange={(e) => updateExp(i,'to',e.target.value)} className="input-field" /></Field>}
                          </div>
                          <div className="flex items-center gap-2 md:col-span-2">
                            <input type="checkbox" id={`exp-c-${i}`} checked={exp.current} onChange={(e) => updateExp(i,'current',e.target.checked)} />
                            <label htmlFor={`exp-c-${i}`} className="text-xs font-bold text-muted">Currently working here</label>
                          </div>
                          <div className="md:col-span-2">
                            <Field label="Description">
                              <textarea value={exp.description} onChange={(e) => updateExp(i,'description',e.target.value)} className="input-field min-h-[80px] resize-y" placeholder="Describe your responsibilities and key achievements..." />
                            </Field>
                          </div>
                        </div>
                      </EntryCard>
                    ))}
                  </div>
                )}
              </section>
            )}

            {/* ── CERTIFICATES ── */}
            {activeTab === 'Certificates' && !isRecruiter && (
              <section>
                <div className="flex items-center justify-between mb-2">
                  <SectionTitle title="Certificates & Achievements" />
                  <AddBtn onClick={addCert} />
                </div>
                <p className="text-xs text-muted mb-5">
                  Add professional certificates, awards, or achievements. Upload the actual certificate file (PDF or image) from your device — just like LinkedIn.
                </p>

                {form.certificates.length === 0 ? (
                  <EmptyState icon="shield" label="No certificates yet. Add your AWS, Google, or course certifications." onAdd={addCert} />
                ) : (
                  <div className="space-y-6">
                    {form.certificates.map((cert, i) => (
                      <EntryCard key={i} onRemove={() => removeCert(i)} highlight>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                          <Field label="Certificate / Achievement Title *">
                            <input value={cert.title} onChange={(e) => updateCert(i,'title',e.target.value)} className="input-field" placeholder="AWS Certified Solutions Architect" />
                          </Field>
                          <Field label="Issuing Organization">
                            <input value={cert.issuer} onChange={(e) => updateCert(i,'issuer',e.target.value)} className="input-field" placeholder="Amazon Web Services" />
                          </Field>
                          <Field label="Issue Date">
                            <input type="date" value={cert.issueDate?.toString().slice(0,10)||''} onChange={(e) => updateCert(i,'issueDate',e.target.value)} className="input-field" />
                          </Field>
                          <Field label="Credential URL (optional)">
                            <input value={cert.credentialUrl} onChange={(e) => updateCert(i,'credentialUrl',e.target.value)} className="input-field" placeholder="https://www.credly.com/badges/..." />
                          </Field>

                          <div className="md:col-span-2">
                            <Field label="Description / Notes">
                              <textarea value={cert.description} onChange={(e) => updateCert(i,'description',e.target.value)} className="input-field resize-y" rows={2} placeholder="Briefly describe what this certification covers..." />
                            </Field>
                          </div>

                          {/* ── File upload zone ── */}
                          <div className="md:col-span-2">
                            <label className="text-[10px] font-black uppercase text-muted tracking-widest block mb-2">
                              Upload Certificate File
                              <span className="ml-2 font-normal normal-case tracking-normal text-muted/70">(PDF, JPG, PNG, WEBP — max 5 MB)</span>
                            </label>

                            {cert.fileUrl ? (
                              /* File already uploaded — show preview row */
                              <div className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-xl">
                                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                                  {cert.fileUrl.endsWith('.pdf')
                                    ? <Icon name="document" size={20} className="text-green-700" />
                                    : <img src={`${API_BASE}${cert.fileUrl}`} alt="cert" className="w-10 h-10 object-cover rounded-lg" />
                                  }
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-bold text-green-800 truncate">{cert.filename || 'Uploaded file'}</p>
                                  <div className="flex items-center gap-3 mt-0.5">
                                    <a
                                      href={`${API_BASE}${cert.fileUrl}`}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="text-[10px] font-black text-green-700 uppercase tracking-widest hover:underline flex items-center gap-1"
                                    >
                                      <Icon name="arrowRight" size={10} /> View File
                                    </a>
                                    <span className="text-green-300">|</span>
                                    <button
                                      type="button"
                                      onClick={() => handleRemoveCertFile(i)}
                                      className="text-[10px] font-black text-red-500 uppercase tracking-widest hover:underline flex items-center gap-1"
                                    >
                                      <Icon name="trash" size={10} /> Remove
                                    </button>
                                  </div>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => { certRefs.current[i]?.click(); }}
                                  className="text-[10px] font-black text-green-700 bg-green-100 px-3 py-1.5 rounded-lg hover:bg-green-200 transition-colors flex-shrink-0"
                                >
                                  Replace
                                </button>
                              </div>
                            ) : (
                              /* Drop zone */
                              <button
                                type="button"
                                onClick={() => certRefs.current[i]?.click()}
                                disabled={uploadingCert[i]}
                                className="w-full border-2 border-dashed border-accent/25 rounded-xl p-6 flex flex-col items-center gap-2 hover:border-accent/60 hover:bg-accent/5 transition-all group disabled:opacity-60"
                              >
                                {uploadingCert[i] ? (
                                  <>
                                    <span className="w-8 h-8 border-2 border-accent/30 border-t-accent rounded-full animate-spin" />
                                    <span className="text-xs font-bold text-muted">Uploading...</span>
                                  </>
                                ) : (
                                  <>
                                    <div className="w-10 h-10 bg-accent/10 rounded-xl flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                                      <Icon name="upload" size={20} className="text-accent" />
                                    </div>
                                    <div className="text-center">
                                      <p className="text-sm font-bold text-primary">Click to upload certificate</p>
                                      <p className="text-[10px] text-muted mt-0.5">PDF, JPG, PNG or WEBP · Max 5 MB</p>
                                    </div>
                                  </>
                                )}
                              </button>
                            )}

                            {/* Hidden file input per certificate */}
                            <input
                              ref={(el) => { certRefs.current[i] = el; }}
                              type="file"
                              accept=".pdf,.jpg,.jpeg,.png,.webp"
                              className="hidden"
                              onChange={(e) => handleCertFileChange(e, i)}
                            />
                          </div>
                        </div>
                      </EntryCard>
                    ))}
                  </div>
                )}
              </section>
            )}

            {/* ── LINKS ── */}
            {activeTab === 'Links' && !isRecruiter && (
              <section className="space-y-5">
                <SectionTitle title="Social & Portfolio Links" />
                <Field label="LinkedIn Profile">
                  <input name="linkedin" value={form.links.linkedin} onChange={handleLinkChange} className="input-field" placeholder="https://linkedin.com/in/your-handle" />
                </Field>
                <Field label="GitHub Profile">
                  <input name="github" value={form.links.github} onChange={handleLinkChange} className="input-field" placeholder="https://github.com/your-username" />
                </Field>
                <Field label="Portfolio / Website">
                  <input name="portfolio" value={form.links.portfolio} onChange={handleLinkChange} className="input-field" placeholder="https://yourportfolio.com" />
                </Field>
              </section>
            )}

          </div>

          {/* Save button */}
          <div className="px-8 pb-8 pt-2 border-t border-accent/10">
            <button
              type="submit" disabled={saving}
              className={`btn-primary w-full py-4 font-black uppercase tracking-[0.2em] ${saving ? 'opacity-70 cursor-not-allowed' : ''}`}
            >
              {saving ? 'Saving...' : 'Save Profile'}
            </button>
          </div>
        </form>
      </div>
      <Footer />
    </div>
  );
};

/* ── small reusable sub-components ── */

const SectionTitle = ({ title }) => (
  <h2 className="font-cinzel font-bold text-[10px] text-accent uppercase tracking-[0.25em]">{title}</h2>
);

const Field = ({ label, children }) => (
  <div className="space-y-1.5">
    <label className="text-[10px] font-black uppercase text-muted tracking-widest">{label}</label>
    {children}
  </div>
);

const AddBtn = ({ onClick }) => (
  <button
    type="button" onClick={onClick}
    className="action-pill text-[10px] px-4 py-2 rounded-full font-black uppercase flex items-center gap-1"
  >
    <Icon name="plus" size={12} /> Add
  </button>
);

const EntryCard = ({ children, onRemove, highlight }) => (
  <div className={`p-6 bg-gray-50 rounded-xl border relative ${highlight ? 'border-accent/20' : 'border-gray-100'}`}>
    <button type="button" onClick={onRemove} className="absolute top-4 right-4 text-red-400 hover:text-red-600 transition-colors">
      <Icon name="trash" size={16} />
    </button>
    {children}
  </div>
);

const EmptyState = ({ icon, label, onAdd }) => (
  <div className="p-10 text-center border-2 border-dashed border-accent/10 rounded-xl">
    <Icon name={icon} size={32} className="mx-auto mb-3 text-muted opacity-20" />
    <p className="text-sm text-muted">{label}</p>
    <button type="button" onClick={onAdd} className="text-[10px] font-black text-accent uppercase mt-3 hover:underline">
      Add your first entry
    </button>
  </div>
);

export default Profile;
