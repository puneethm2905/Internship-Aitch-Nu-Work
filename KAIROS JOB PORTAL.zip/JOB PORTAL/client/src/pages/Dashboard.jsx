import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { applicationsAPI, jobsAPI, resumeAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import DashboardCard from '../components/DashboardCard';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import JobCard from '../components/JobCard';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';
import StatusChip from '../components/StatusChip';

const Dashboard = () => {
  const { user } = useAuth();
  const [applications, setApplications] = useState([]);
  const [recommended, setRecommended] = useState([]);
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [appRes, jobRes, resumeRes] = await Promise.all([
          applicationsAPI.getMy(),
          jobsAPI.getAll({ limit: 4 }),
          resumeAPI.getMy(),
        ]);
        setApplications(appRes.data.applications);
        setRecommended(jobRes.data.jobs);
        setResume(resumeRes.data.resume);
      } catch (err) {
        console.error('Dashboard load failed:', err);
      }
      setLoading(false);
    };
    load();
  }, []);

  if (loading) return <Loader />;

  const stats = [
    { icon: 'mail', label: 'Total Applications', value: applications.length, tone: 'accent' },
    { icon: 'clock', label: 'Under Review', value: applications.filter((a) => a.status === 'under-review').length, tone: 'warning' },
    { icon: 'checkCircle', label: 'Shortlisted', value: applications.filter((a) => a.status === 'shortlisted').length, tone: 'success' },
    { icon: 'document', label: 'Resume Status', value: resume ? 'Ready' : 'Missing', tone: resume ? 'success' : 'danger' },
  ];

  const quickLinks = [
    { icon: 'user', label: 'My Profile', to: '/profile', desc: 'Edit your details' },
    { icon: 'document', label: 'Resume', to: '/resume', desc: resume ? 'Update Resume' : 'Upload Now' },
    { icon: 'briefcase', label: 'Browse Jobs', to: '/jobs', desc: 'Find opportunities' },
  ];

  return (
    <div className="page-shell">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-24 pb-16">
        <div className="mb-8">
          <div className="gradient-panel rounded-2xl p-8 shadow-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h1 className="font-cinzel font-bold text-2xl md:text-3xl mb-1 text-primary">
                  Welcome back, {user?.name?.split(' ')[0]}
                </h1>
                <p className="text-muted text-sm">Track your journey and discover roles that fit your ambition.</p>
              </div>
              <div className="flex gap-3 flex-wrap">
                <Link to="/jobs" className="btn-primary text-sm py-2 px-6">Explore Jobs</Link>
                <Link to="/profile" className="btn-outline text-sm py-2 px-6">My Profile</Link>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {stats.map((stat) => <DashboardCard key={stat.label} {...stat} />)}
        </div>

        {!resume && (
          <div className="danger-panel flex items-center gap-4 p-5 rounded-xl mb-8">
            <Icon name="alert" size={24} className="text-danger flex-shrink-0" />
            <div className="flex-1">
              <p className="font-semibold text-sm text-danger">Action Required: Resume Missing</p>
              <p className="text-xs text-muted">You cannot apply for most jobs without a resume.</p>
            </div>
            <Link to="/resume" className="btn-primary text-xs py-2 px-4 whitespace-nowrap" style={{ background: '#dc2626', border: 'none' }}>
              Upload Now
            </Link>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h2 className="font-cinzel font-semibold text-lg mb-4 text-primary uppercase tracking-wider">
              Recent Applications
            </h2>
            {applications.length === 0 ? (
              <div className="card p-10 text-center border-dashed border-2">
                <div className="icon-tile icon-tile-lg mx-auto mb-4 opacity-50">
                  <Icon name="briefcase" size={24} />
                </div>
                <p className="font-semibold mb-1 text-primary">No applications yet</p>
                <p className="text-sm mb-6 text-muted">Start your career journey by browsing our listings.</p>
                <Link to="/jobs" className="btn-primary text-sm py-2.5 px-8">Browse Openings</Link>
              </div>
            ) : (
              <div className="space-y-4">
                {applications.slice(0, 5).map((app) => (
                  <div key={app._id} className="card p-5 flex items-center justify-between gap-4 hover:border-accent transition-all">
                    <div className="min-w-0">
                      <p className="font-bold text-sm truncate text-primary">{app.job?.title}</p>
                      <p className="text-xs text-accent font-semibold">{app.job?.company}</p>
                      <div className="flex items-center gap-2 mt-1.5 text-muted text-[10px] font-medium">
                        <span className="flex items-center gap-1"><Icon name="location" size={10} /> {app.job?.location}</span>
                        <span>•</span>
                        <span className="uppercase">{app.job?.type}</span>
                      </div>
                    </div>
                    <div className="flex-shrink-0 text-right">
                      <StatusChip status={app.status} />
                      <p className="text-[10px] mt-2.5 text-muted font-medium">
                        Applied {new Date(app.appliedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-8">
            <div>
              <h2 className="font-cinzel font-semibold text-lg mb-4 text-primary uppercase tracking-wider">
                Quick Actions
              </h2>
              <div className="space-y-3">
                {quickLinks.map((item) => (
                  <Link key={item.to} to={item.to} className="card p-4 flex items-center gap-4 group hover:border-accent transition-all">
                    <div className="icon-tile group-hover:bg-accent group-hover:text-primary transition-colors">
                      <Icon name={item.icon} size={20} />
                    </div>
                    <div>
                      <p className="font-bold text-sm text-primary">{item.label}</p>
                      <p className="text-[10px] text-muted font-medium">{item.desc}</p>
                    </div>
                    <Icon name="arrowRight" size={16} className="ml-auto text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>

        {recommended.length > 0 && (
          <div className="mt-12">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="font-cinzel font-semibold text-lg text-primary uppercase tracking-wider">
                  Discover More Roles
                </h2>
                <p className="text-xs text-muted">Fresh opportunities from the marketplace.</p>
              </div>
              <Link to="/jobs" className="text-xs font-bold text-accent inline-flex items-center gap-1 hover:underline">
                View All <Icon name="arrowRight" size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {recommended.map((job) => <JobCard key={job._id} job={job} />)}
            </div>
          </div>
        )}
      </div>
      <Footer />
    </div>
  );
};

export default Dashboard;
