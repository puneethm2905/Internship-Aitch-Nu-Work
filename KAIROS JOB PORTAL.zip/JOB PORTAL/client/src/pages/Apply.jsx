import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { applicationsAPI, jobsAPI, resumeAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';

const Apply = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isSeeker } = useAuth();
  const [job, setJob] = useState(null);
  const [resume, setResume] = useState(null);
  const [coverLetter, setCoverLetter] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    // Role Guard: Prevents non-seekers from accessing the application pipeline
    if (user && !isSeeker) {
      toast.error("Access Denied: Only Job Seekers can express interest.");
      navigate(`/jobs/${id}`);
      return;
    }

    Promise.all([jobsAPI.getById(id), resumeAPI.getMy()])
      .then(([jobRes, resumeRes]) => {
        setJob(jobRes.data.job);
        setResume(resumeRes.data.resume);
      })
      .catch(() => navigate('/jobs'))
      .finally(() => setLoading(false));
  }, [id, navigate, user, isSeeker]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    if (!resume) {
      toast.error('Strategic Asset Missing: Please synchronize a resume first.');
      return;
    }

    setSubmitting(true);
    try {
      await applicationsAPI.apply({ jobId: id, coverLetter });
      toast.success('Intelligence Transmitted: Application logged.');
      navigate('/dashboard');
    } catch (err) {
      const message = err.response?.data?.message;
      if (message?.includes('already applied')) {
        toast('Your profile is already synchronized with this role.');
      } else {
        toast.error(message || 'Transmission failed');
      }
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <Loader />;

  return (
    <div className="page-shell bg-gray-50/50">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 sm:px-6 pt-24 pb-16">
        <Link to={`/jobs/${id}`} className="text-accent text-[10px] font-black uppercase tracking-[0.2em] mb-8 inline-flex items-center gap-2 hover:translate-x-[-4px] transition-transform">
          <Icon name="arrowLeft" size={14} /> Back to Briefing
        </Link>

        <h1 className="font-cinzel font-black text-3xl mb-2 text-primary tracking-widest uppercase">Express Interest</h1>
        <p className="mb-10 text-sm text-muted font-medium">
          Applying for <span className="text-accent font-bold">{job?.title}</span> at <span className="text-primary font-black uppercase tracking-tight">{job?.company}</span>
        </p>

        {!resume && (
          <div className="bg-amber-50 border border-amber-200 flex items-center gap-4 p-6 rounded-2xl mb-8 shadow-sm">
            <Icon name="alert" size={24} className="text-warning flex-shrink-0" />
            <div className="flex-1">
               <p className="text-xs font-black text-amber-900 uppercase tracking-widest">Asset Sync Required</p>
               <p className="text-[11px] text-amber-800 font-medium">Recruiters prioritize verified resumes. <Link to="/resume" className="underline font-black decoration-2">Upload Now</Link></p>
            </div>
          </div>
        )}

        <div className="card p-10 bg-white border border-accent/10 shadow-2xl rounded-3xl">
          <div className="bg-primary p-6 rounded-2xl mb-10 border border-white/5 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-accent opacity-5 -mr-8 -mt-8 rounded-full" />
            <div className="flex items-center gap-5 relative z-10">
              <div className="icon-tile bg-accent text-primary font-black w-12 h-12 flex items-center justify-center rounded-xl">{job?.company?.charAt(0)}</div>
              <div>
                <p className="font-black text-white text-sm tracking-tight">{job?.title}</p>
                <div className="flex items-center gap-2 mt-1 text-[9px] text-accent font-black uppercase tracking-widest">
                  <span>{job?.company}</span>
                  <span className="opacity-30">•</span>
                  <span>{job?.location}</span>
                </div>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label className="text-[10px] font-black uppercase text-muted tracking-[0.2em] mb-4 block">Asset Validation</label>
              {resume ? (
                <div className="bg-gray-50 border border-gray-100 flex items-center justify-between p-5 rounded-2xl shadow-inner">
                  <div className="flex items-center gap-4">
                    <div className="p-2.5 bg-green-600 text-white rounded-xl shadow-lg shadow-green-200"><Icon name="checkCircle" size={20} /></div>
                    <div className="min-w-0">
                      <span className="text-sm font-bold text-primary truncate block max-w-[180px]">{resume.originalName}</span>
                      <span className="text-[9px] text-green-600 uppercase font-black tracking-tighter">Synchronized for submission</span>
                    </div>
                  </div>
                  <Link to="/resume" className="text-[9px] font-black text-accent uppercase tracking-widest hover:underline">Change</Link>
                </div>
              ) : (
                <Link to="/resume" className="flex flex-col items-center justify-center border-2 border-dashed border-accent/20 p-12 rounded-2xl text-muted hover:border-accent hover:bg-accent/5 transition-all group">
                  <Icon name="upload" size={32} className="mb-3 opacity-20 group-hover:opacity-100 transition-opacity" />
                  <p className="text-[10px] font-black uppercase tracking-[0.2em]">Synchronize Profile Resume</p>
                </Link>
              )}
            </div>

            <div>
              <label className="text-[10px] font-black uppercase text-muted tracking-[0.2em] mb-4 block">Strategy Statement <span className="font-medium opacity-40 lowercase">(Optional Cover Letter)</span></label>
              <textarea
                className="input-field py-5 px-6 min-h-[250px] resize-none text-sm font-medium leading-relaxed bg-gray-50 border-gray-100 focus:bg-white"
                value={coverLetter}
                onChange={(event) => setCoverLetter(event.target.value)}
                placeholder="Detail your unique alignment with this role..."
                maxLength={2000}
              />
              <div className="flex justify-between items-center mt-3">
                <span className="text-[9px] text-muted font-bold uppercase tracking-widest">Maximum Impact: 2000 Chars</span>
                <span className="text-[9px] font-black text-accent uppercase tracking-widest">{coverLetter.length} / 2000</span>
              </div>
            </div>

            <div className="flex gap-4 pt-6 border-t border-gray-100">
              <button 
                type="submit" 
                disabled={submitting || !resume} 
                className={`btn-primary flex-1 py-4 font-black uppercase tracking-[0.2em] shadow-xl shadow-accent/20 ${submitting || !resume ? 'opacity-30 grayscale cursor-not-allowed' : 'hover:scale-[1.02]'} transition-all`}
              >
                {submitting ? 'Transmitting Intelligence...' : 'Commit Application'}
              </button>
            </div>
          </form>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Apply;