import { useCallback, useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { jobsAPI } from '../services/api';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import JobCard from '../components/JobCard';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';

/**
 * Standardized constants for filtering.
 * Matches backend enums and Home categories.
 */
const TYPES = ['Full-Time', 'Part-Time', 'Remote', 'Hybrid', 'Internship', 'Contract'];
const CATEGORIES = ['Technology', 'Management', 'Marketing', 'Finance', 'Design', 'Healthcare', 'Education', 'Other'];
const EXPERIENCES = ['0-1 years', '1-3 years', '3-5 years', '5+ years'];

const JobList = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [jobs, setJobs] = useState([]);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  
  // Local filter state synchronized with URL search parameters
  const [filters, setFilters] = useState({
    search: searchParams.get('search') || '',
    type: searchParams.get('type') || '',
    category: searchParams.get('category') || '',
    experience: searchParams.get('experience') || '',
    page: parseInt(searchParams.get('page')) || 1,
  });

  /**
   * Fetches job listings based on current filters.
   * Cleans empty parameters before making the API request.
   */
  const fetchJobs = useCallback(async () => {
    setLoading(true);
    try {
      const params = { limit: 9, ...filters };
      Object.keys(params).forEach((key) => !params[key] && delete params[key]);
      
      const res = await jobsAPI.getAll(params);
      setJobs(res.data.jobs);
      setTotal(res.data.total);
      setPages(res.data.pages);
      
      // Update URL to match filter state for deep-linking
      setSearchParams(params);
    } catch (err) {
      console.error("Job fetch failed:", err);
    }
    setLoading(false);
  }, [filters, setSearchParams]);

  useEffect(() => { fetchJobs(); }, [fetchJobs]);

  const setFilter = (key, value) => {
    setFilters((current) => ({ ...current, [key]: value, page: 1 }));
  };

  const clearFilters = () => {
    setFilters({ search: '', type: '', category: '', experience: '', page: 1 });
    setSearchParams({});
  };

  const FilterSection = ({ title, options, filterKey }) => (
    <div className="mb-6">
      <h4 className="filter-title font-cinzel text-xs font-bold text-accent uppercase tracking-wider mb-3">
        {title}
      </h4>
      <div className="space-y-1">
        {['', ...options].map((option) => {
          const active = filters[filterKey] === option;
          return (
            <button
              key={option || 'all'}
              type="button"
              onClick={() => setFilter(filterKey, option)}
              className={`filter-option w-full text-left px-3 py-2 rounded-lg text-sm transition-all ${
                active ? 'bg-accent text-primary font-bold shadow-sm' : 'text-muted hover:bg-accent/5'
              }`}
            >
              {option || 'All Listings'}
            </button>
          );
        })}
      </div>
    </div>
  );

  const Sidebar = () => (
    <div className="space-y-1">
      <div className="flex items-center justify-between mb-6">
        <h3 className="font-cinzel font-bold text-primary tracking-widest">FILTERS</h3>
        {(filters.type || filters.category || filters.experience) && (
          <button type="button" onClick={clearFilters} className="text-[10px] font-bold uppercase accent-link border-b border-accent">
            Reset
          </button>
        )}
      </div>
      <FilterSection title="Work Arrangement" options={TYPES} filterKey="type" />
      <div className="divider-line my-4 border-t border-accent/10" />
      <FilterSection title="Industry Category" options={CATEGORIES} filterKey="category" />
      <div className="divider-line my-4 border-t border-accent/10" />
      <FilterSection title="Experience Level" options={EXPERIENCES} filterKey="experience" />
    </div>
  );

  const activeFilters = Object.entries(filters)
    .filter(([key, value]) => value && key !== 'page')
    .map(([key, value]) => ({ key, value }));

  return (
    <div className="page-shell">
      <Navbar />

      {/* Hero Header for Marketplace[cite: 22] */}
      <div className="section-band pt-20 bg-accent/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
          <div className="display-badge text-[10px] font-bold px-3 py-1 rounded-full mb-4 inline-flex items-center gap-2 bg-accent/10 text-accent uppercase tracking-tighter">
            <Icon name="briefcase" size={12} /> Marketplace Inventory
          </div>
          <h1 className="font-cinzel font-black text-3xl md:text-4xl mb-2 text-primary tracking-widest">
            FIND YOUR MOMENT
          </h1>
          <p className="mb-8 text-sm text-muted">Analyzing {total} live opportunities across the network[cite: 22].</p>
          
          {/* Integrated Search Input[cite: 22] */}
          <div className="flex flex-col sm:flex-row gap-3 max-w-3xl">
            <div className="relative flex-1">
              <Icon name="search" size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" />
              <input
                type="text"
                placeholder="Search job title, company, or keyword..."
                value={filters.search}
                onChange={(event) => setFilter('search', event.target.value)}
                className="input-field pl-12 w-full py-4 bg-white shadow-lg border-none"
                onKeyDown={(event) => event.key === 'Enter' && fetchJobs()}
              />
            </div>
            <button type="button" onClick={fetchJobs} className="btn-primary px-10 py-4 font-bold uppercase tracking-widest">
              Search
            </button>
            <button 
              type="button" 
              className="lg:hidden btn-outline px-6 py-4 inline-flex items-center justify-center gap-2 border-accent text-accent" 
              onClick={() => setSidebarOpen(true)}
            >
              <Icon name="filter" size={16} /> Filters
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        <div className="flex flex-col lg:flex-row gap-10">
          {/* Desktop Filtering Sidebar[cite: 22] */}
          <aside className="hidden lg:block w-64 flex-shrink-0">
            <div className="filter-panel sticky top-28 rounded-2xl p-8 bg-white border border-accent/10 shadow-sm">
              <Sidebar />
            </div>
          </aside>

          {/* Mobile Filter Modal[cite: 22] */}
          {sidebarOpen && (
            <div className="fixed inset-0 z-50 flex lg:hidden">
              <button type="button" className="absolute inset-0 bg-primary/40 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
              <div className="relative w-80 h-full overflow-y-auto p-8 bg-white shadow-2xl animate-in slide-in-from-left">
                <button type="button" className="absolute top-6 right-6 text-primary" onClick={() => setSidebarOpen(false)}>
                  <Icon name="close" size={24} />
                </button>
                <Sidebar />
              </div>
            </div>
          )}

          <div className="flex-1 min-w-0">
            {/* Display Active Filter Chips[cite: 22] */}
            {activeFilters.length > 0 && (
              <div className="flex flex-wrap gap-2 mb-8">
                {activeFilters.map(({ key, value }) => (
                  <span key={key} className="bg-accent/10 text-accent text-[10px] font-bold px-4 py-1.5 rounded-full inline-flex items-center gap-2 uppercase">
                    {value}
                    <button type="button" onClick={() => setFilter(key, '')} className="hover:text-primary">
                      <Icon name="close" size={10} />
                    </button>
                  </span>
                ))}
                <button onClick={clearFilters} className="text-[10px] font-bold text-muted uppercase hover:text-accent">
                  Clear All
                </button>
              </div>
            )}

            {loading ? (
              <Loader fullScreen={false} />
            ) : jobs.length === 0 ? (
              <div className="card p-20 text-center border-dashed border-2 border-accent/10">
                <div className="icon-tile icon-tile-lg mx-auto mb-6 bg-accent/5 text-accent opacity-30"><Icon name="search" size={32} /></div>
                <p className="font-cinzel font-black text-xl mb-2 text-primary tracking-widest uppercase">Zero Matches Found</p>
                <p className="mb-8 text-sm text-muted">Broaden your criteria to discover hidden gems in the marketplace[cite: 22].</p>
                <button type="button" onClick={clearFilters} className="btn-primary px-10 py-3 uppercase tracking-widest font-bold">Reset Inventory</button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 mb-12">
                  {jobs.map((job) => <JobCard key={job._id} job={job} />)}
                </div>

                {/* Professional Pagination Controls[cite: 22] */}
                {pages > 1 && (
                  <div className="flex items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={() => setFilters((current) => ({ ...current, page: Math.max(1, current.page - 1) }))}
                      disabled={filters.page === 1}
                      className={`p-3 rounded-full border transition-all ${
                        filters.page === 1 ? 'opacity-20 cursor-not-allowed' : 'border-accent text-accent hover:bg-accent hover:text-primary'
                      }`}
                    >
                      <Icon name="arrowLeft" size={18} />
                    </button>
                    
                    <div className="flex gap-2">
                      {[...Array(pages)].map((_, index) => (
                        <button
                          key={index}
                          type="button"
                          onClick={() => setFilters((current) => ({ ...current, page: index + 1 }))}
                          className={`w-10 h-10 rounded-full font-bold text-xs transition-all ${
                            filters.page === index + 1 
                              ? 'bg-primary text-accent shadow-lg scale-110' 
                              : 'text-muted hover:bg-accent/10'
                          }`}
                        >
                          {index + 1}
                        </button>
                      ))}
                    </div>

                    <button
                      type="button"
                      onClick={() => setFilters((current) => ({ ...current, page: Math.min(pages, current.page + 1) }))}
                      disabled={filters.page === pages}
                      className={`p-3 rounded-full border transition-all ${
                        filters.page === pages ? 'opacity-20 cursor-not-allowed' : 'border-accent text-accent hover:bg-accent hover:text-primary'
                      }`}
                    >
                      <Icon name="arrowRight" size={18} />
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default JobList;