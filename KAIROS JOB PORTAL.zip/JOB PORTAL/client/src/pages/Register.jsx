import { useState, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import Navbar from '../components/Navbar';
import Icon from '../components/Icon';

const Register = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [form, setForm] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirm: '',
    role: 'seeker',
    companyName: '',
    companyWebsite: '',
  });

  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (searchParams.get('role') === 'recruiter') {
      setForm((prev) => ({ ...prev, role: 'recruiter' }));
    }
  }, [searchParams]);

  const validate = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = 'Name is required';
    if (!form.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) errs.email = 'Valid email required';
    if (form.password.length < 6) errs.password = 'Password must be at least 6 characters';
    if (form.password !== form.confirm) errs.confirm = 'Passwords do not match';
    if (form.role === 'recruiter' && !form.companyName.trim()) {
      errs.companyName = 'Company name is required';
    }
    return errs;
  };

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
    setErrors((prev) => ({ ...prev, [e.target.name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) {
      setErrors(errs);
      return;
    }

    setLoading(true);
    try {
      const payload = {
        name: form.name,
        email: form.email,
        phone: form.phone,
        password: form.password,
        role: form.role,
        ...(form.role === 'recruiter' && {
          companyDetails: {
            companyName: form.companyName,
            website: form.companyWebsite,
          },
        }),
      };

      const res = await authAPI.register(payload);
      login(res.data.token, res.data.user);
      toast.success(`Welcome to KAIROS!`);
      navigate(form.role === 'recruiter' ? '/recruiter/dashboard' : '/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-shell">
      <Navbar />
      <div className="min-h-screen flex items-center justify-center px-4 pt-24 pb-12">
        <div className="w-full max-w-md">
          <div className="auth-header">
            <div className="auth-logo">K</div>
            <h1 className="auth-title">Create Account</h1>
            <p className="auth-subtitle">Begin your KAIROS journey</p>
          </div>

          <div className="flex p-1 bg-surface-panel rounded-xl mb-6 border border-accent/10">
            <button
              type="button"
              onClick={() => setForm((prev) => ({ ...prev, role: 'seeker' }))}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg transition-all ${
                form.role === 'seeker' ? 'bg-accent text-primary shadow-sm' : 'text-muted'
              }`}
            >
              <Icon name="user" size={16} /> Job Seeker
            </button>
            <button
              type="button"
              onClick={() => setForm((prev) => ({ ...prev, role: 'recruiter' }))}
              className={`flex-1 flex items-center justify-center gap-2 py-2 text-sm font-medium rounded-lg transition-all ${
                form.role === 'recruiter' ? 'bg-accent text-primary shadow-sm' : 'text-muted'
              }`}
            >
              <Icon name="briefcase" size={16} /> Recruiter
            </button>
          </div>

          <div className="card p-8">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="form-label">Full Name *</label>
                <input name="name" value={form.name} onChange={handleChange} className="input-field" placeholder="John Doe" />
                {errors.name && <p className="text-xs mt-1 text-danger">{errors.name}</p>}
              </div>

              {form.role === 'recruiter' && (
                <div className="space-y-4">
                  <div>
                    <label className="form-label">Company Name *</label>
                    <input name="companyName" value={form.companyName} onChange={handleChange} className="input-field" placeholder="Nexus Tech" />
                    {errors.companyName && <p className="text-xs mt-1 text-danger">{errors.companyName}</p>}
                  </div>
                  <div>
                    <label className="form-label">Company Website</label>
                    <input name="companyWebsite" value={form.companyWebsite} onChange={handleChange} className="input-field" placeholder="https://nexus.com" />
                  </div>
                </div>
              )}

              <div>
                <label className="form-label">Email Address *</label>
                <input name="email" type="email" value={form.email} onChange={handleChange} className="input-field" placeholder="john@example.com" />
                {errors.email && <p className="text-xs mt-1 text-danger">{errors.email}</p>}
              </div>

              <div>
                <label className="form-label">Phone Number</label>
                <input name="phone" value={form.phone} onChange={handleChange} className="input-field" placeholder="+91 98765 43210" />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="form-label">Password *</label>
                  <input name="password" type="password" value={form.password} onChange={handleChange} className="input-field" placeholder="Min 6 chars" />
                </div>
                <div>
                  <label className="form-label">Confirm *</label>
                  <input name="confirm" type="password" value={form.confirm} onChange={handleChange} className="input-field" placeholder="Repeat" />
                </div>
              </div>
              {(errors.password || errors.confirm) && (
                <p className="text-xs text-danger">{errors.password || errors.confirm}</p>
              )}

              <button
                type="submit"
                disabled={loading}
                className={`btn-primary w-full mt-4 font-semibold ${loading ? 'opacity-70' : ''}`}
              >
                {loading ? 'Creating Account...' : `Register as ${form.role === 'recruiter' ? 'Recruiter' : 'Seeker'}`}
              </button>
            </form>

            <div className="mt-6 text-center text-sm text-muted">
              Already have an account?{' '}
              <Link to="/login" className="font-medium accent-link hover:underline">Sign In</Link>
            </div>
          </div>

          <p className="text-center text-xs mt-6 text-muted">
            Are you an admin?{' '}
            <Link to="/admin/login" className="accent-link hover:underline font-semibold">Admin Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Register;
