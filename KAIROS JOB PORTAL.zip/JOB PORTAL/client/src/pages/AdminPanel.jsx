import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { adminAPI, applicationsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import DashboardCard from '../components/DashboardCard';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import StatusChip from '../components/StatusChip';

const STATUSES = ['applied', 'under-review', 'shortlisted', 'rejected'];

const AdminPanel = () => {
  const { user, logout } = useAuth();
  const { section } = useParams();
  const navigate = useNavigate();
  const [activeSection, setActiveSection] = useState(section || 'dashboard');
  const [stats, setStats] = useState(null);
  const [jobs, setJobs] = useState([]);
  const [applications, setApplications] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const [statsRes, jobsRes, appsRes, usersRes] = await Promise.all([
        adminAPI.getStats(),
        adminAPI.getJobs(),
        applicationsAPI.getAll(),
        adminAPI.getUsers(),
      ]);
      setStats(statsRes.data.stats);
      setJobs(jobsRes.data.jobs);
      setApplications(appsRes.data.applications);
      setUsers(usersRes.data.users);
    } catch (err) {
      toast.error('Failed to load admin data');
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);
  useEffect(() => { if (section) setActiveSection(section); }, [section]);

  const goTo = (next) => {
    setActiveSection(next);
    navigate(`/admin/${next}`);
    setSidebarOpen(false);
  };

  const handleVerifyJob = async (jobId) => {
    try {
      const res = await adminAPI.verifyJob(jobId);
      setJobs((prev) => prev.map((j) => (j._id === jobId ? res.data.job : j)));
      toast.success(res.data.message);
    } catch {
      toast.error('Verification failed');
    }
  };

  const handleDelete = async () => {
    try {
      if (deleteTarget.type === 'job') {
        await adminAPI.getJobs(); // placeholder — actual delete handled by jobsAPI
        const { jobsAPI } = await import('../services/api');
        await jobsAPI.delete(deleteTarget.id);
        setJobs((prev) => prev.filter((j) => j._id !== deleteTarget.id));
      } else {
        await adminAPI.deleteUser(deleteTarget.id);
        setUsers((prev) => prev.filter((u) => u._id !== deleteTarget.id));
      }
      toast.success(`${deleteTarget.type === 'job' ? 'Job' : 'User'} deleted`);
    } catch {
      toast.error('Delete failed');
    } finally {
      setDeleteTarget(null);
    }
  };

  const handleStatusChange = async (appId, status) => {
    try {
      await applicationsAPI.updateStatus(appId, status);
      setApplications((prev) => prev.map((a) => (a._id === appId ? { ...a, status } : a)));
      toast.success(`Status updated to ${status}`);
    } catch {
      toast.error('Failed to update status');
    }
  };

  if (loading && !stats) return <Loader />;

  const navItems = [
    { id: 'dashboard', label: 'Overview', icon: 'dashboard' },
    { id: 'jobs', label: 'Jobs', icon: 'briefcase' },
    { id: 'applications', label: 'Applications', icon: 'mail' },
    { id: 'users', label: 'Users', icon: 'users' },
  ];

  const Sidebar = () => (
    <div className="flex flex-col h-full bg-primary border-r border-accent/10">
      <div className="p-6 border-b border-accent/10">
        <div className="flex items-center gap-3">
          <div className="brand-mark bg-accent text-primary">K</div>
          <div>
            <div className="font-cinzel font-bold text-accent tracking-widest">KAIROS</div>
            <div className="text-[10px] uppercase text-muted font-black">Platform Oversight</div>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(({ id, label, icon }) => (
          <button
            key={id}
            onClick={() => goTo(id)}
            className={`admin-nav-item ${activeSection === id ? 'admin-nav-item-active' : ''}`}
          >
            <Icon name={icon} size={18} />
            <span>{label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-accent/10">
        <div className="flex items-center gap-3 mb-4">
          <div className="avatar-mark bg-accent text-primary">{user?.name?.charAt(0)}</div>
          <div className="min-w-0">
            <div className="text-sm font-semibold truncate text-white">{user?.name}</div>
            <div className="text-[10px] text-accent font-bold uppercase tracking-tighter">Root Admin</div>
          </div>
        </div>
        <button
          type="button"
          onClick={() => { logout(); navigate('/'); }}
          className="w-full btn-outline border-accent/30 text-accent text-xs py-2"
        >
          Sign Out
        </button>
      </div>
    </div>
  );

  const renderContent = () => {
    if (activeSection === 'dashboard') {
      return (
        <div>
          <PageTitle title="Platform Overview" subtitle={`Monitoring ${stats?.totalUsers || 0} registered users`} />
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <DashboardCard icon="users" label="Total Users" value={stats?.totalUsers || 0} tone="accent" />
            <DashboardCard icon="briefcase" label="Live Listings" value={stats?.activeJobs || 0} tone="primary" />
            <DashboardCard icon="mail" label="Total Applications" value={stats?.totalApplications || 0} tone="success" />
            <DashboardCard icon="clock" label="Pending Verification" value={stats?.pendingJobs || 0} tone="warning" />
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AdminCard title="Recent Applications" onViewAll={() => goTo('applications')}>
              {applications.slice(0, 5).map((app) => (
                <div key={app._id} className="flex items-center justify-between gap-3 p-2 hover:bg-accent/5 rounded">
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-primary truncate">{app.user?.name}</p>
                    <p className="text-[10px] text-muted truncate">{app.job?.title}</p>
                  </div>
                  <StatusChip status={app.status} />
                </div>
              ))}
            </AdminCard>
            <AdminCard title="Recent Postings" onViewAll={() => goTo('jobs')}>
              {jobs.slice(0, 5).map((job) => (
                <div key={job._id} className="flex items-center justify-between gap-3 p-2 hover:bg-accent/5 rounded">
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-primary truncate">{job.title}</p>
                    <p className="text-[10px] text-muted truncate">{job.company}</p>
                  </div>
                  <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded-full ${
                    job.isVerified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                  }`}>
                    {job.isVerified ? 'Verified' : 'Pending'}
                  </span>
                </div>
              ))}
            </AdminCard>
          </div>
        </div>
      );
    }

    if (activeSection === 'jobs') {
      return (
        <div>
          <PageTitle title="Job Management" subtitle={`${jobs.length} total listings`} />
          <div className="space-y-3 mt-6">
            {jobs.length === 0 && <p className="empty-note">No job listings found.</p>}
            {jobs.map((job) => (
              <div key={job._id} className="card p-5 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4 min-w-0">
                  <div className="company-mark bg-accent/10 text-accent font-black flex-shrink-0">
                    {job.company?.charAt(0)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-sm text-primary truncate">{job.title}</p>
                      {job.isVerified && (
                        <span className="text-[8px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded-full font-black flex-shrink-0">LIVE</span>
                      )}
                    </div>
                    <p className="text-[10px] text-muted uppercase font-bold tracking-tighter">
                      {job.company} • {job.location} • {job.applicationsCount || 0} applicants
                    </p>
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  <button
                    onClick={() => handleVerifyJob(job._id)}
                    className={`action-pill text-[9px] px-3 py-1.5 border rounded-full font-bold ${
                      job.isVerified
                        ? 'border-yellow-200 text-yellow-700 bg-yellow-50'
                        : 'border-green-200 text-green-700 bg-green-50'
                    }`}
                  >
                    {job.isVerified ? 'Unverify' : 'Verify'}
                  </button>
                  <button
                    onClick={() => setDeleteTarget({ type: 'job', id: job._id, name: job.title })}
                    className="text-[9px] px-3 py-1.5 text-red-600 bg-red-50 rounded-full font-bold"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (activeSection === 'applications') {
      return (
        <div>
          <PageTitle title="Global Application Pipeline" subtitle={`${applications.length} total submissions`} />
          <div className="space-y-3 mt-6">
            {applications.length === 0 && <p className="empty-note">No applications found.</p>}
            {applications.map((app) => (
              <div key={app._id} className="card p-5 flex items-start justify-between bg-white gap-4">
                <div className="flex gap-4 min-w-0">
                  <div className="avatar-mark bg-primary text-accent flex-shrink-0">{app.user?.name?.charAt(0)}</div>
                  <div className="min-w-0">
                    <p className="font-bold text-sm text-primary">{app.user?.name}</p>
                    <p className="text-xs text-accent font-bold truncate">{app.job?.title} at {app.job?.company}</p>
                    <p className="text-[10px] text-muted mt-0.5">{app.user?.email}</p>
                    <div className="mt-2"><StatusChip status={app.status} /></div>
                  </div>
                </div>
                <select
                  value={app.status}
                  onChange={(e) => handleStatusChange(app._id, e.target.value)}
                  className="admin-select flex-shrink-0"
                >
                  {STATUSES.map((s) => (
                    <option key={s} value={s}>{s.replace('-', ' ').toUpperCase()}</option>
                  ))}
                </select>
              </div>
            ))}
          </div>
        </div>
      );
    }

    if (activeSection === 'users') {
      return (
        <div>
          <PageTitle title="User Directory" subtitle={`${users.length} registered accounts`} />
          <div className="space-y-3 mt-6">
            {users.length === 0 && <p className="empty-note">No users found.</p>}
            {users.map((u) => (
              <div key={u._id} className="card p-5 flex items-center justify-between bg-white">
                <div className="flex items-center gap-4">
                  <div className="avatar-mark border border-accent/10">{u.name?.charAt(0)}</div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-bold text-sm text-primary">{u.name}</p>
                      <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-black uppercase ${
                        u.role === 'recruiter' ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {u.role}
                      </span>
                    </div>
                    <p className="text-[10px] text-muted">{u.email}</p>
                    {u.role === 'recruiter' && u.companyDetails?.companyName && (
                      <p className="text-[10px] text-accent font-bold">{u.companyDetails.companyName}</p>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => setDeleteTarget({ type: 'user', id: u._id, name: u.name })}
                  className="text-red-500 p-2 hover:bg-red-50 rounded-lg transition-colors"
                >
                  <Icon name="trash" size={18} />
                </button>
              </div>
            ))}
          </div>
        </div>
      );
    }
  };

  return (
    <div className="flex h-screen bg-primary overflow-hidden">
      <aside className="hidden lg:block w-64 flex-shrink-0"><Sidebar /></aside>

      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-64 h-full"><Sidebar /></div>
        </div>
      )}

      <div className="flex-1 flex flex-col overflow-hidden bg-gray-50">
        <header className="flex items-center justify-between px-6 py-4 bg-white border-b border-accent/10">
          <div className="flex items-center gap-4">
            <button className="lg:hidden" onClick={() => setSidebarOpen(true)}>
              <Icon name="menu" size={20} />
            </button>
            <h2 className="font-cinzel font-bold text-lg text-primary uppercase tracking-[0.15em]">
              {navItems.find((n) => n.id === activeSection)?.label || activeSection}
            </h2>
          </div>
          <Link to="/" className="text-[10px] font-black text-accent uppercase tracking-widest border-b-2 border-accent">
            Exit Portal
          </Link>
        </header>
        <main className="flex-1 overflow-y-auto p-6 lg:p-8">
          {renderContent()}
        </main>
      </div>

      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white p-8 rounded-2xl shadow-2xl max-w-sm text-center border border-accent/10">
            <div className="w-12 h-12 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="trash" size={24} />
            </div>
            <h3 className="font-cinzel font-black text-lg mb-2 text-primary">Confirm Delete</h3>
            <p className="text-xs text-muted mb-6 leading-relaxed">
              Permanently remove <strong>"{deleteTarget.name}"</strong>? This cannot be undone.
            </p>
            <div className="flex gap-3">
              <button onClick={handleDelete} className="flex-1 btn-primary py-3 font-bold rounded-xl" style={{ background: '#dc2626', border: 'none' }}>
                Delete
              </button>
              <button onClick={() => setDeleteTarget(null)} className="flex-1 btn-outline py-3 font-bold rounded-xl">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const PageTitle = ({ title, subtitle }) => (
  <div className="mb-6">
    <h1 className="font-cinzel font-black text-2xl text-primary tracking-widest uppercase">{title}</h1>
    {subtitle && <p className="text-[10px] font-bold text-muted uppercase tracking-tighter mt-1">{subtitle}</p>}
  </div>
);

const AdminCard = ({ title, onViewAll, children }) => (
  <div className="card p-6 bg-white">
    <h3 className="font-cinzel font-bold text-[10px] text-accent uppercase tracking-[0.2em] border-b border-accent/10 pb-3 mb-4">
      {title}
    </h3>
    <div className="space-y-2">{children}</div>
    {onViewAll && (
      <button onClick={onViewAll} className="mt-4 text-[9px] font-black text-accent uppercase tracking-widest flex items-center gap-1 hover:underline">
        View All <Icon name="arrowRight" size={10} />
      </button>
    )}
  </div>
);

export default AdminPanel;
