import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const SplashScreen = () => {
  const navigate = useNavigate();
  const [phase, setPhase] = useState(0); 

  useEffect(() => {
    // Orchestrated phase transitions for premium UX[cite: 22]
    const t1 = setTimeout(() => setPhase(1), 800);  // Logo Reveal
    const t2 = setTimeout(() => setPhase(2), 2200); // Fade Out Start
    const t3 = setTimeout(() => navigate('/'), 3000); // Transition to Home
    return () => [t1, t2, t3].forEach(clearTimeout);
  }, [navigate]);

  return (
    <div className={`splash-screen bg-primary ${phase === 2 ? 'splash-fade' : ''}`}>
      <div className="splash-glow absolute inset-0 pointer-events-none opacity-20" />

      {/* Synchronized orbital rings[cite: 22] */}
      <div className="splash-ring splash-ring-outer border-accent/20" />
      <div className="splash-ring splash-ring-inner border-accent/40" />

      <div className={`splash-logo bg-accent text-primary shadow-gold flex items-center justify-center font-black text-3xl ${phase >= 1 ? 'splash-logo-active' : ''}`}>
        <span>K</span>
      </div>

      <h1 className="splash-title font-cinzel font-black text-accent tracking-[0.5em] mt-8 text-2xl uppercase">KAIROS</h1>
      
      <div className={`splash-divider h-px bg-accent/30 mx-auto transition-all duration-1000 ${phase >= 1 ? 'w-32 opacity-100' : 'w-0 opacity-0'}`} />

      <p className={`splash-tagline text-accent font-cinzel text-[10px] uppercase tracking-[0.3em] mt-4 italic ${phase >= 1 ? 'opacity-60 translate-y-0' : 'opacity-0 translate-y-4'} transition-all duration-1000`}>
        Luck meets opportunity at the perfect moment.
      </p>
    </div>
  );
};

export default SplashScreen;