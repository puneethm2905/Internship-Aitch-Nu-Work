import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { resumeAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';

/**
 * ResumeUpload Component
 * Exclusively for Seekers to manage their professional assets.
 */
const ResumeUpload = () => {
  const { user, isSeeker } = useAuth();
  const navigate = useNavigate();
  const [resume, setResume] = useState(null);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef();

  useEffect(() => {
    // Security Guard: Only seekers possess the authority to manage resumes.
    if (user && !isSeeker) {
      toast.error("Resume management is restricted to Job Seeker accounts.");
      navigate('/dashboard');
      return;
    }

    // Fetch existing synchronized asset.
    resumeAPI.getMy()
      .then((res) => setResume(res.data.resume))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [user, isSeeker, navigate]);

  /**
   * Handles file transmission to the backend.
   * Includes validation for file type and payload size.
   */
  const upload = async (file) => {
    if (!file) return;

    // MIME type validation for professional document standards[cite: 22].
    const allowed = [
      'application/pdf', 
      'application/msword', 
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ];
    
    if (!allowed.includes(file.type)) {
      toast.error('Invalid format. Please use PDF, DOC, or DOCX.');
      return;
    }

    // Capacity check: 5MB system limit[cite: 22].
    if (file.size > 5 * 1024 * 1024) {
      toast.error('File exceeds the 5MB transmission limit.');
      return;
    }

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append('resume', file);
      
      // Execute multi-part/form-data request[cite: 22].
      const res = await resumeAPI.upload(formData);
      setResume(res.data.resume);
      toast.success('Asset synchronized successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Synchronization failed.');
    } finally {
      setUploading(false);
    }
  };

  const formatSize = (bytes) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  if (loading) return <Loader />;

  return (
    <div className="page-shell bg-gray-50/50">
      <Navbar />
      <div className="max-w-2xl mx-auto px-4 sm:px-6 pt-24 pb-16">
        
        {/* Header Branding[cite: 22] */}
        <div className="mb-8">
          <div className="display-badge text-[10px] font-black px-3 py-1 rounded-full mb-3 inline-flex bg-accent/10 text-accent uppercase tracking-[0.2em]">
            <Icon name="document" size={12} className="mr-1" /> Profile Credentials
          </div>
          <h1 className="font-cinzel font-black text-3xl mb-2 text-primary tracking-widest uppercase">My Resume</h1>
          <p className="text-sm text-muted italic font-serif">"Luck meets opportunity through a polished briefing[cite: 22]."</p>
        </div>

        {/* Existing Asset Preview[cite: 22] */}
        {resume && (
          <div className="success-panel rounded-2xl p-6 mb-8 flex items-center justify-between gap-4 border border-accent/20 bg-white shadow-xl animate-in fade-in slide-in-from-top-4">
            <div className="flex items-center gap-4">
              <div className="icon-tile bg-accent text-primary p-3 rounded-xl shadow-lg"><Icon name="checkCircle" size={22} /></div>
              <div>
                <p className="font-bold text-sm text-primary truncate max-w-[200px]">{resume.originalName}</p>
                <p className="text-[10px] mt-1 text-muted uppercase font-black tracking-tighter">
                  {formatSize(resume.size)} • Synchronized {new Date(resume.uploadedAt).toLocaleDateString()}
                </p>
              </div>
            </div>
            <a href={resume.fileUrl} target="_blank" rel="noopener noreferrer" className="btn-outline border-accent text-accent text-[10px] font-black py-2.5 px-6 hover:bg-accent hover:text-primary uppercase tracking-widest transition-all">
              Inspect
            </a>
          </div>
        )}

        {/* Interactive Upload Zone[cite: 22] */}
        <div
          className={`upload-zone rounded-[2.5rem] p-16 text-center cursor-pointer border-2 border-dashed transition-all duration-300 ${
            dragOver ? 'border-accent bg-accent/5 scale-[1.02] shadow-2xl' : 'border-accent/20 bg-white shadow-sm hover:border-accent/40'
          }`}
          onClick={() => fileRef.current?.click()}
          onDrop={(event) => {
            event.preventDefault();
            setDragOver(false);
            upload(event.dataTransfer.files[0]);
          }}
          onDragOver={(event) => {
            event.preventDefault();
            setDragOver(true);
          }}
          onDragLeave={() => setDragOver(false)}
        >
          <input
            ref={fileRef}
            type="file"
            accept=".pdf,.doc,.docx"
            className="hidden"
            onChange={(event) => upload(event.target.files[0])}
          />

          {uploading ? (
            <div className="py-6">
              <div className="loader-ring loader-ring-lg mx-auto mb-6 border-accent" />
              <p className="font-black text-accent uppercase tracking-[0.3em] text-[10px]">Transmitting Intelligence...</p>
            </div>
          ) : (
            <>
              <div className="icon-tile icon-tile-xl mx-auto mb-8 bg-primary text-accent shadow-2xl scale-125">
                <Icon name={resume ? 'download' : 'upload'} size={28} />
              </div>
              <h3 className="font-cinzel font-black text-2xl mb-3 text-primary tracking-widest uppercase">
                {resume ? 'Redefine Asset' : 'Initialize Upload'}
              </h3>
              <p className="text-xs mb-8 text-muted font-medium">Drop your professional briefing here or click to browse the system[cite: 22].</p>
              <div className="inline-flex bg-primary text-accent text-[9px] font-black px-6 py-2.5 rounded-full uppercase tracking-widest shadow-lg">
                PDF • DOC • DOCX | Max 5MB
              </div>
            </>
          )}
        </div>

        {/* Strategic Guidance Section[cite: 22] */}
        <div className="card mt-12 p-8 bg-white border border-accent/5 shadow-xl rounded-3xl">
          <h3 className="font-cinzel font-bold text-xs mb-6 text-accent uppercase tracking-[0.2em] border-b border-gray-100 pb-4">Strategic Tips</h3>
          <ul className="space-y-4 text-xs text-muted font-bold">
            {[
              'Maintain a 1-2 page briefing for optimal reviewer focus.',
              'Structure sections clearly: Summary, Arsenal, Experience, Education.',
              'Quantify achievements (e.g., "Increased efficiency by 40%").',
              'Preserve document integrity by using PDF format for submissions.',
            ].map((tip) => (
              <li key={tip} className="flex items-start gap-3 leading-relaxed">
                <Icon name="check" size={14} className="text-accent mt-0.5 flex-shrink-0" />
                <span>{tip}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex gap-4 mt-10">
          <Link to="/dashboard" className="btn-outline flex-1 py-4 text-[10px] font-black uppercase tracking-widest border-accent/20 text-muted hover:text-primary hover:bg-accent hover:border-accent">
            Dashboard
          </Link>
          <Link to="/jobs" className="btn-primary flex-1 py-4 text-[10px] font-black uppercase tracking-widest shadow-xl shadow-accent/20">
            Browse Opportunities
          </Link>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default ResumeUpload;