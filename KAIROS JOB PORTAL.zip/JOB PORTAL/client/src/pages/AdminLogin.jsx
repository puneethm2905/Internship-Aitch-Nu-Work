import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { authAPI } from '../services/api';
import Icon from '../components/Icon';
import Navbar from '../components/Navbar';

const AdminLogin = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setLoading(true);
    try {
      const res = await authAPI.adminLogin(form);
      login(res.data.token, res.data.user);
      toast.success('Admin access granted');
      navigate('/admin');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Invalid admin credentials');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-shell">
      <Navbar />
      <div className="min-h-screen flex items-center justify-center px-4 pt-16">
        <div className="w-full max-w-md">
          <div className="auth-header">
            <div className="admin-icon icon-tile icon-tile-lg mx-auto mb-4">
              <Icon name="shield" size={26} />
            </div>
            <h1 className="auth-title">Admin Portal</h1>
            <p className="auth-subtitle">Restricted access for authorized personnel only</p>
          </div>

          <div className="card p-8 strong-card">
            <div className="display-badge w-full px-4 py-3 rounded-lg mb-6 text-sm">
              <Icon name="lock" size={16} />
              <span>This section is for KAIROS administrators only</span>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="form-label">Admin Email</label>
                <input
                  type="email"
                  value={form.email}
                  onChange={(event) => setForm((current) => ({ ...current, email: event.target.value }))}
                  className="input-field"
                  placeholder="admin@kairos.com"
                  required
                />
              </div>
              <div>
                <label className="form-label">Admin Password</label>
                <input
                  type="password"
                  value={form.password}
                  onChange={(event) => setForm((current) => ({ ...current, password: event.target.value }))}
                  className="input-field"
                  placeholder="Admin password"
                  required
                />
              </div>

              <button type="submit" disabled={loading} className={`btn-primary w-full mt-2 ${loading ? 'loading-control' : ''}`}>
                {loading ? 'Authenticating...' : 'Access Admin Panel'}
              </button>
            </form>
          </div>

          <p className="text-center text-xs mt-6 text-muted">
            Not an admin? <Link to="/login" className="accent-link">User Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
