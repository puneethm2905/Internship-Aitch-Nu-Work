import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { recruiterAPI, jobsAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import DashboardCard from '../components/DashboardCard';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';
import StatusChip from '../components/StatusChip';

const STATUSES = ['applied', 'under-review', 'shortlisted', 'rejected'];

const emptyTest = { testLink: '', testDeadline: '', instructions: '' };
const emptyInterview = {
  interviewType: 'remote',
  dateTime: '',
  location: '',
  meetingLink: '',
  contactPerson: '',
  additionalNotes: '',
};

const RecruiterDashboard = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const [myJobs, setMyJobs] = useState([]);
  const [applicants, setApplicants] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('applicants');
  const [selectedApplicant, setSelectedApplicant] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);

  const [actionPanel, setActionPanel] = useState(null);
  const [testForm, setTestForm] = useState({ ...emptyTest });
  const [interviewForm, setInterviewForm] = useState({ ...emptyInterview });
  const [sending, setSending] = useState(false);

  const loadData = async () => {
    try {
      const [jobsRes, appsRes] = await Promise.all([
        recruiterAPI.getMyJobs(),
        recruiterAPI.getApplicants(),
      ]);
      setMyJobs(jobsRes.data.jobs);
      setApplicants(appsRes.data.applications);
    } catch {
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const handleStatusChange = async (appId, status) => {
    try {
      await recruiterAPI.updateApplicantStatus(appId, status);
      setApplicants((prev) => prev.map((a) => (a._id === appId ? { ...a, status } : a)));
      if (selectedApplicant?._id === appId) setSelectedApplicant((prev) => ({ ...prev, status }));
      toast.success(`Status updated to "${status}"`);
    } catch {
      toast.error('Failed to update status');
    }
  };

  const handleDeleteJob = async () => {
    if (!deleteTarget) return;
    try {
      await jobsAPI.delete(deleteTarget);
      setMyJobs((prev) => prev.filter((j) => j._id !== deleteTarget));
      toast.success('Job listing deleted');
    } catch {
      toast.error('Failed to delete listing');
    } finally {
      setDeleteTarget(null);
    }
  };

  const handleSendTest = async (e) => {
    e.preventDefault();
    if (!testForm.testLink) { toast.error('Test link is required'); return; }
    setSending(true);
    try {
      await recruiterAPI.sendAptitudeTest(selectedApplicant._id, testForm);
      toast.success(`Assessment invite sent to ${selectedApplicant.user?.name}!`);
      setActionPanel(null);
      setTestForm({ ...emptyTest });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send assessment invite');
    } finally {
      setSending(false);
    }
  };

  const handleSendInterview = async (e) => {
    e.preventDefault();
    if (!interviewForm.dateTime) { toast.error('Date & time is required'); return; }
    setSending(true);
    try {
      await recruiterAPI.sendInterviewInvite(selectedApplicant._id, interviewForm);
      toast.success(`Interview invite sent to ${selectedApplicant.user?.name}!`);
      setActionPanel(null);
      setInterviewForm({ ...emptyInterview });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send interview invite');
    } finally {
      setSending(false);
    }
  };

  const openPanel = (panel) => {
    setActionPanel((prev) => (prev === panel ? null : panel));
  };

  if (loading) return <Loader />;

  const stats = [
    { icon: 'briefcase', label: 'Active Listings', value: myJobs.length, tone: 'primary' },
    { icon: 'users', label: 'Total Applicants', value: applicants.length, tone: 'accent' },
    { icon: 'clock', label: 'Awaiting Review', value: applicants.filter((a) => a.status === 'applied').length, tone: 'warning' },
    { icon: 'checkCircle', label: 'Shortlisted', value: applicants.filter((a) => a.status === 'shortlisted').length, tone: 'success' },
  ];

  return (
    <div className="page-shell">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-24 pb-16">

        <div className="mb-8">
          <div className="gradient-panel rounded-2xl p-8 shadow-lg">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
              <div>
                <h1 className="font-cinzel font-bold text-2xl md:text-3xl mb-1 text-primary">
                  {user?.companyDetails?.companyName || 'Recruiter'} Dashboard
                </h1>
                <p className="text-muted text-sm">Manage job postings and communicate with candidates.</p>
              </div>
              <Link to="/recruiter/post-job" className="btn-primary flex items-center gap-2 px-6 py-3 whitespace-nowrap">
                <Icon name="plus" size={18} /> Post New Job
              </Link>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          {stats.map((stat) => <DashboardCard key={stat.label} {...stat} />)}
        </div>

        <div className="flex gap-2 mb-6 border-b border-accent/10">
          {['applicants', 'listings'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-6 py-3 text-xs font-black uppercase tracking-[0.2em] transition-all capitalize ${
                activeTab === tab ? 'text-accent border-b-2 border-accent' : 'text-muted hover:text-primary'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {activeTab === 'applicants' && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            <div className="lg:col-span-2 space-y-2 max-h-[80vh] overflow-y-auto pr-1">
              {applicants.length === 0 ? (
                <div className="card p-12 text-center border-dashed border-2">
                  <Icon name="mail" size={36} className="mx-auto mb-3 text-muted opacity-20" />
                  <p className="font-semibold text-primary">No applications yet</p>
                  <p className="text-xs text-muted mt-1">Candidates appear here once they apply.</p>
                </div>
              ) : (
                applicants.map((app) => (
                  <button
                    key={app._id}
                    onClick={() => { setSelectedApplicant(app); setActionPanel(null); }}
                    className={`card w-full p-4 flex items-center justify-between text-left transition-all hover:border-accent ${
                      selectedApplicant?._id === app._id ? 'border-accent bg-accent/5' : ''
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-9 h-9 rounded-full bg-accent/10 text-accent font-black flex items-center justify-center flex-shrink-0 text-sm">
                        {app.user?.name?.charAt(0)}
                      </div>
                      <div className="min-w-0">
                        <p className="font-bold text-sm text-primary truncate">{app.user?.name}</p>
                        <p className="text-[10px] text-muted truncate">{app.job?.title}</p>
                      </div>
                    </div>
                    <StatusChip status={app.status} />
                  </button>
                ))
              )}
            </div>

            <div className="lg:col-span-3 space-y-4">
              {selectedApplicant ? (
                <>
                  <div className="card p-7 bg-white">
                    <div className="flex items-start justify-between mb-5">
                      <div className="flex items-center gap-4">
                        <div className="w-14 h-14 rounded-2xl bg-primary text-accent font-black text-xl flex items-center justify-center flex-shrink-0">
                          {selectedApplicant.user?.name?.charAt(0)}
                        </div>
                        <div>
                          <h2 className="font-cinzel font-black text-xl text-primary">{selectedApplicant.user?.name}</h2>
                          <p className="text-xs text-accent font-bold uppercase tracking-wider">
                            {selectedApplicant.job?.title}
                          </p>
                        </div>
                      </div>
                      <button onClick={() => { setSelectedApplicant(null); setActionPanel(null); }} className="text-muted hover:text-primary">
                        <Icon name="close" size={20} />
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-5">
                      <ContactItem icon="mail" label="Email" value={selectedApplicant.user?.email} href={`mailto:${selectedApplicant.user?.email}`} />
                      <ContactItem icon="phone" label="Phone" value={selectedApplicant.user?.phone || 'Not provided'} href={selectedApplicant.user?.phone ? `tel:${selectedApplicant.user?.phone}` : null} />
                    </div>

                    <div className="mb-5">
                      <p className="text-[10px] font-black uppercase text-muted tracking-widest mb-2">Resume</p>
                      {selectedApplicant.resume ? (
                        <a
                          href={`${import.meta.env.VITE_API_URL?.replace('/api', '') || 'http://localhost:5000'}${selectedApplicant.resume.fileUrl}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-3 p-4 border border-accent/20 rounded-xl hover:border-accent hover:bg-accent/5 transition-all group"
                        >
                          <div className="icon-tile bg-accent/10 text-accent">
                            <Icon name="document" size={20} />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-bold text-primary truncate">{selectedApplicant.resume.originalName}</p>
                            <p className="text-[10px] text-muted">Click to open PDF</p>
                          </div>
                          <Icon name="download" size={16} className="text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                        </a>
                      ) : (
                        <p className="text-sm text-muted italic p-4 border border-dashed border-accent/20 rounded-xl">No resume uploaded</p>
                      )}
                    </div>

                    {selectedApplicant.coverLetter && (
                      <div className="mb-5">
                        <p className="text-[10px] font-black uppercase text-muted tracking-widest mb-2">Strategy Statement</p>
                        <div className="p-4 bg-gray-50 rounded-xl border border-gray-100 text-sm text-gray-700 leading-relaxed max-h-32 overflow-y-auto">
                          {selectedApplicant.coverLetter}
                        </div>
                      </div>
                    )}

                    <div className="mb-5">
                      <p className="text-[10px] font-black uppercase text-muted tracking-widest mb-3">Update Status</p>
                      <div className="flex flex-wrap gap-2">
                        {STATUSES.map((status) => (
                          <button
                            key={status}
                            onClick={() => handleStatusChange(selectedApplicant._id, status)}
                            className={`px-4 py-2 rounded-full text-xs font-black uppercase tracking-wider border transition-all ${
                              selectedApplicant.status === status
                                ? 'bg-accent text-primary border-accent'
                                : 'border-accent/20 text-muted hover:border-accent hover:text-accent'
                            }`}
                          >
                            {status.replace('-', ' ')}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <p className="text-[10px] font-black uppercase text-muted tracking-widest mb-3">Communication Actions</p>
                      <div className="flex gap-2 flex-wrap">
                        <button
                          onClick={() => openPanel('test')}
                          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider border transition-all ${
                            actionPanel === 'test'
                              ? 'bg-green-600 text-white border-green-600'
                              : 'border-green-200 text-green-700 bg-green-50 hover:bg-green-100'
                          }`}
                        >
                          <Icon name="check" size={14} /> Send Assessment
                        </button>
                        <button
                          onClick={() => openPanel('interview')}
                          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-wider border transition-all ${
                            actionPanel === 'interview'
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'border-blue-200 text-blue-700 bg-blue-50 hover:bg-blue-100'
                          }`}
                        >
                          <Icon name="calendar" size={14} /> Schedule Interview
                        </button>
                      </div>
                    </div>
                  </div>

                  {actionPanel === 'test' && (
                    <div className="card p-7 bg-white border-l-4 border-green-500">
                      <h3 className="font-cinzel font-bold text-sm text-green-700 uppercase tracking-[0.2em] mb-1 flex items-center gap-2">
                        <Icon name="check" size={16} /> Send Aptitude Assessment
                      </h3>
                      <p className="text-xs text-muted mb-5">
                        An email with the test link will be sent to <strong>{selectedApplicant.user?.email}</strong>
                      </p>
                      <form onSubmit={handleSendTest} className="space-y-4">
                        <FormField label="Test / Assessment Link *">
                          <input
                            value={testForm.testLink}
                            onChange={(e) => setTestForm((p) => ({ ...p, testLink: e.target.value }))}
                            className="input-field"
                            placeholder="https://yourtestplatform.com/test/xyz"
                            required
                          />
                        </FormField>
                        <FormField label="Submission Deadline">
                          <input
                            type="datetime-local"
                            value={testForm.testDeadline}
                            onChange={(e) => setTestForm((p) => ({ ...p, testDeadline: e.target.value }))}
                            className="input-field"
                          />
                        </FormField>
                        <FormField label="Instructions for the Candidate">
                          <textarea
                            value={testForm.instructions}
                            onChange={(e) => setTestForm((p) => ({ ...p, instructions: e.target.value }))}
                            className="input-field resize-none"
                            rows={3}
                            placeholder="e.g. Complete all 30 questions. No calculator allowed. Time limit: 45 minutes."
                          />
                        </FormField>
                        <div className="flex gap-3 pt-2">
                          <button
                            type="submit"
                            disabled={sending}
                            className="flex-1 py-3 bg-green-600 text-white rounded-xl text-xs font-black uppercase tracking-[0.15em] hover:bg-green-700 disabled:opacity-60 flex items-center justify-center gap-2"
                          >
                            {sending ? <><span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Sending...</> : 'Send Assessment Email'}
                          </button>
                          <button type="button" onClick={() => setActionPanel(null)} className="btn-outline px-6 py-3 text-xs font-bold rounded-xl">Cancel</button>
                        </div>
                      </form>
                    </div>
                  )}

                  {actionPanel === 'interview' && (
                    <div className="card p-7 bg-white border-l-4 border-blue-500">
                      <h3 className="font-cinzel font-bold text-sm text-blue-700 uppercase tracking-[0.2em] mb-1 flex items-center gap-2">
                        <Icon name="calendar" size={16} /> Schedule Interview
                      </h3>
                      <p className="text-xs text-muted mb-5">
                        An interview invitation email will be sent to <strong>{selectedApplicant.user?.email}</strong>
                      </p>
                      <form onSubmit={handleSendInterview} className="space-y-4">
                        <FormField label="Interview Format *">
                          <div className="flex gap-2">
                            {['remote', 'onsite'].map((type) => (
                              <button
                                key={type}
                                type="button"
                                onClick={() => setInterviewForm((p) => ({ ...p, interviewType: type }))}
                                className={`flex-1 py-2.5 text-xs font-bold rounded-lg border transition-all capitalize ${
                                  interviewForm.interviewType === type
                                    ? 'bg-blue-600 text-white border-blue-600'
                                    : 'border-accent/20 text-muted hover:border-accent'
                                }`}
                              >
                                {type === 'remote' ? '🌐 Remote' : '🏢 Onsite'}
                              </button>
                            ))}
                          </div>
                        </FormField>
                        <FormField label="Date & Time *">
                          <input
                            type="datetime-local"
                            value={interviewForm.dateTime}
                            onChange={(e) => setInterviewForm((p) => ({ ...p, dateTime: e.target.value }))}
                            className="input-field"
                            required
                          />
                        </FormField>
                        {interviewForm.interviewType === 'remote' ? (
                          <FormField label="Video Call / Meeting Link">
                            <input
                              value={interviewForm.meetingLink}
                              onChange={(e) => setInterviewForm((p) => ({ ...p, meetingLink: e.target.value }))}
                              className="input-field"
                              placeholder="https://meet.google.com/xxx-xxxx-xxx"
                            />
                          </FormField>
                        ) : (
                          <FormField label="Venue / Office Address">
                            <input
                              value={interviewForm.location}
                              onChange={(e) => setInterviewForm((p) => ({ ...p, location: e.target.value }))}
                              className="input-field"
                              placeholder="4th Floor, Nexus Tower, MG Road, Bengaluru"
                            />
                          </FormField>
                        )}
                        <FormField label="Contact Person">
                          <input
                            value={interviewForm.contactPerson}
                            onChange={(e) => setInterviewForm((p) => ({ ...p, contactPerson: e.target.value }))}
                            className="input-field"
                            placeholder="Priya Sharma, HR Manager — priya@company.com"
                          />
                        </FormField>
                        <FormField label="Additional Notes for Candidate">
                          <textarea
                            value={interviewForm.additionalNotes}
                            onChange={(e) => setInterviewForm((p) => ({ ...p, additionalNotes: e.target.value }))}
                            className="input-field resize-none"
                            rows={3}
                            placeholder="e.g. Please bring a copy of your resume. Interview will be 45 mins with 2 rounds."
                          />
                        </FormField>
                        <div className="flex gap-3 pt-2">
                          <button
                            type="submit"
                            disabled={sending}
                            className="flex-1 py-3 bg-blue-600 text-white rounded-xl text-xs font-black uppercase tracking-[0.15em] hover:bg-blue-700 disabled:opacity-60 flex items-center justify-center gap-2"
                          >
                            {sending ? <><span className="w-3 h-3 border-2 border-white/30 border-t-white rounded-full animate-spin" /> Sending...</> : 'Send Interview Invitation'}
                          </button>
                          <button type="button" onClick={() => setActionPanel(null)} className="btn-outline px-6 py-3 text-xs font-bold rounded-xl">Cancel</button>
                        </div>
                      </form>
                    </div>
                  )}
                </>
              ) : (
                <div className="card p-16 text-center border-dashed border-2">
                  <Icon name="users" size={40} className="mx-auto mb-4 text-muted opacity-20" />
                  <p className="font-semibold text-primary">Select an applicant</p>
                  <p className="text-sm text-muted mt-1">Click any applicant on the left to manage them.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {activeTab === 'listings' && (
          <div className="space-y-3">
            {myJobs.length === 0 ? (
              <div className="card p-12 text-center border-dashed border-2">
                <Icon name="briefcase" size={40} className="mx-auto mb-4 text-muted opacity-20" />
                <p className="font-semibold text-primary mb-4">No job listings yet</p>
                <Link to="/recruiter/post-job" className="btn-primary text-sm py-2.5 px-8">Create Your First Listing</Link>
              </div>
            ) : (
              myJobs.map((job) => (
                <div key={job._id} className="card p-5 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="company-mark bg-accent/10 text-accent font-black flex-shrink-0">
                      {job.company?.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="font-bold text-sm text-primary truncate">{job.title}</p>
                        <span className={`text-[8px] px-1.5 py-0.5 rounded-full font-black uppercase flex-shrink-0 ${
                          job.isVerified ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                        }`}>
                          {job.isVerified ? 'Live' : 'Pending'}
                        </span>
                      </div>
                      <p className="text-[10px] text-muted uppercase font-bold tracking-tighter">
                        {job.location} • {job.type} • {job.applicationsCount || 0} applicants
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <Link to={`/recruiter/edit-job/${job._id}`} className="action-pill text-[10px] px-3 py-1.5 rounded-full font-bold flex items-center gap-1">
                      <Icon name="edit" size={12} /> Edit
                    </Link>
                    <Link to={`/jobs/${job._id}`} className="action-pill text-[10px] px-3 py-1.5 rounded-full font-bold flex items-center gap-1">
                      <Icon name="arrowRight" size={12} /> View
                    </Link>
                    <button
                      onClick={() => setDeleteTarget(job._id)}
                      className="text-[10px] px-3 py-1.5 text-red-600 bg-red-50 rounded-full font-bold"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>

      {deleteTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white p-8 rounded-2xl shadow-2xl max-w-sm text-center border border-accent/10">
            <div className="w-12 h-12 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Icon name="trash" size={24} />
            </div>
            <h3 className="font-cinzel font-black text-lg mb-2 text-primary">Delete Listing?</h3>
            <p className="text-xs text-muted mb-6">This action cannot be undone.</p>
            <div className="flex gap-3">
              <button onClick={handleDeleteJob} className="flex-1 py-3 font-bold rounded-xl text-white bg-red-600 hover:bg-red-700">Delete</button>
              <button onClick={() => setDeleteTarget(null)} className="flex-1 btn-outline py-3 font-bold rounded-xl">Cancel</button>
            </div>
          </div>
        </div>
      )}

      <Footer />
    </div>
  );
};

const ContactItem = ({ icon, label, value, href }) => (
  <div className="p-3 bg-gray-50 rounded-xl border border-gray-100">
    <p className="text-[9px] font-black uppercase text-muted tracking-widest mb-1">{label}</p>
    {href ? (
      <a href={href} className="text-sm font-bold text-accent hover:underline flex items-center gap-1 truncate">
        <Icon name={icon} size={12} /> {value}
      </a>
    ) : (
      <p className="text-sm font-bold text-primary">{value}</p>
    )}
  </div>
);

const FormField = ({ label, children }) => (
  <div>
    <label className="text-[10px] font-black uppercase tracking-widest text-muted block mb-1.5">{label}</label>
    {children}
  </div>
);

export default RecruiterDashboard;
