import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { jobsAPI } from '../services/api';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import JobCard from '../components/JobCard';
import Navbar from '../components/Navbar';
import { useAuth } from '../context/AuthContext';

const StatCard = ({ value, label }) => (
  <div className="text-center p-6 border-r border-accent/10 last:border-0">
    <div className="font-cinzel font-black text-4xl mb-2 text-accent tracking-tighter">{value}</div>
    <div className="text-xs uppercase tracking-widest text-muted font-semibold">{label}</div>
  </div>
);

const CategoryCard = ({ icon, label, count }) => (
  <Link to={`/jobs?category=${label}`} className="block group">
    <div className="card p-6 text-center h-full hover:border-accent transition-all duration-300 hover:-translate-y-1">
      <div className="icon-tile mx-auto mb-3 group-hover:scale-110 transition-transform">
        <Icon name={icon} size={21} />
      </div>
      <h3 className="font-semibold text-sm mb-1 text-primary">{label}</h3>
      <p className="text-xs text-muted">{count} openings</p>
    </div>
  </Link>
);

const TestimonialCard = ({ name, role, text, avatar }) => (
  <div className="card p-6">
    <p className="text-sm mb-4 leading-relaxed text-muted italic">"{text}"</p>
    <div className="flex items-center gap-3">
      <div className="avatar-mark testimonial-avatar">{avatar}</div>
      <div>
        <div className="text-sm font-semibold text-primary">{name}</div>
        <div className="text-xs text-muted">{role}</div>
      </div>
    </div>
  </div>
);

const ContactInfoCard = ({ icon, title, value, href }) => (
  <a
    href={href}
    target={href?.startsWith('http') ? '_blank' : undefined}
    rel="noopener noreferrer"
    className="card p-5 flex items-center gap-4 group hover:border-accent transition-all"
  >
    <div className="icon-tile flex-shrink-0 group-hover:scale-110 transition-transform">
      <Icon name={icon} size={20} />
    </div>
    <div>
      <p className="text-[10px] font-black uppercase tracking-widest text-muted mb-0.5">{title}</p>
      <p className="text-sm font-bold text-primary group-hover:text-accent transition-colors">{value}</p>
    </div>
  </a>
);

const Home = () => {
  const [featuredJobs, setFeaturedJobs] = useState([]);
  const [search, setSearch] = useState('');
  const [contactForm, setContactForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [contactSending, setContactSending] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();
  const contactRef = useRef(null);

  useEffect(() => {
    jobsAPI.getAll({ limit: 6 }).then((res) => setFeaturedJobs(res.data.jobs)).catch(() => {});
  }, []);

  const handleSearch = (event) => {
    event.preventDefault();
    navigate(`/jobs?search=${search}`);
  };

  const handleContactChange = (e) => {
    setContactForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleContactSubmit = async (e) => {
    e.preventDefault();
    if (!contactForm.name || !contactForm.email || !contactForm.message) {
      toast.error('Please fill in all required fields');
      return;
    }
    setContactSending(true);
    await new Promise((r) => setTimeout(r, 1400));
    toast.success("Message received! We'll get back to you within 24 hours.");
    setContactForm({ name: '', email: '', subject: '', message: '' });
    setContactSending(false);
  };

  const scrollToContact = () => {
    contactRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const categories = [
    { icon: 'briefcase', label: 'Technology', count: '240+' },
    { icon: 'chart', label: 'Management', count: '95+' },
    { icon: 'palette', label: 'Design', count: '80+' },
    { icon: 'megaphone', label: 'Marketing', count: '120+' },
    { icon: 'currency', label: 'Finance', count: '65+' },
    { icon: 'shield', label: 'Healthcare', count: '55+' },
  ];

  const steps = [
    { num: '01', title: 'Register', desc: 'Join as a Seeker or Company in seconds.' },
    { num: '02', title: 'Setup Profile', desc: 'Detail your expertise or your company mission.' },
    { num: '03', title: 'Post/Browse', desc: 'List new opportunities or find your next role.' },
    { num: '04', title: 'Apply/Review', desc: 'Submit applications or review top talent.' },
    { num: '05', title: 'Connect', desc: 'Interview and hire at the perfect moment.' },
  ];

  const benefits = [
    { icon: 'shield', title: 'Verified Profiles', desc: 'We verify both recruiters and candidates for maximum trust.' },
    { icon: 'dashboard', title: 'Smart Dashboards', desc: 'Specialized interfaces for managing applications or job postings.' },
    { icon: 'trending', title: 'Real-time Alerts', desc: 'Instant Gmail notifications when application statuses change.' },
    { icon: 'search', title: 'Global Reach', desc: 'Connect with premium talent and companies across the industry.' },
  ];

  const testimonials = [
    { name: 'Aryan Mehta', role: 'Software Engineer at Nexus', text: 'KAIROS helped me find my dream job in just 2 weeks. The interface is clean and genuine.', avatar: 'A' },
    { name: 'Siddharth V.', role: 'Hiring Manager at Innovate', text: 'As a recruiter, the dashboard makes tracking applicants incredibly simple and organized.', avatar: 'S' },
    { name: 'Rohan Das', role: 'UX Designer', text: 'The status tracking feature kept me informed at every step. No more guessing!', avatar: 'R' },
  ];

  const contactInfo = [
    { icon: 'mail', title: 'Email Us', value: 'support@kairos.careers', href: 'mailto:support@kairos.careers' },
    { icon: 'phone', title: 'Call Us', value: '+91 98765 43210', href: 'tel:+919876543210' },
    { icon: 'location', title: 'Our Office', value: 'Bengaluru, Karnataka, India', href: 'https://maps.google.com/?q=Bengaluru,India' },
    { icon: 'globe', title: 'Working Hours', value: 'Mon – Sat, 9 AM – 6 PM IST', href: '#' },
  ];

  return (
    <div className="page-shell">
      <Navbar />

      {/* ─── Hero ─────────────────────────────────────────────────────────── */}
      <section className="hero-section relative flex items-center justify-center pt-16 overflow-hidden">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {Array.from({ length: 12 }).map((_, index) => (
            <span key={index} className={`hero-dot hero-dot-${index + 1}`} />
          ))}
        </div>
        <div className="hero-glow absolute inset-0 pointer-events-none" />

        <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
          <div className="display-badge text-xs font-semibold px-4 py-2 rounded-full mb-8 tracking-widest bg-accent/10 text-accent">
            <Icon name="diamond" size={14} className="inline mr-1" /> PREMIUM TALENT MARKETPLACE
          </div>

          <h1 className="hero-title glow-text font-cinzel font-black mb-6 uppercase">KAIROS</h1>
          <div className="thin-gold-line w-32 h-px mx-auto mb-6" />
          <p className="hero-kicker italic mb-4 tracking-wider text-accent font-serif text-lg">
            Luck meets opportunity at the perfect moment.
          </p>
          <p className="mb-10 text-lg max-w-2xl mx-auto text-muted leading-relaxed">
            The bridge between elite professionals and the world's most innovative companies.
          </p>

          <form onSubmit={handleSearch} className="flex gap-3 max-w-xl mx-auto mb-10">
            <input
              type="text"
              placeholder="Search roles, companies, or keywords..."
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              className="input-field flex-1 text-base bg-white/5 backdrop-blur-sm"
            />
            <button type="submit" className="btn-primary whitespace-nowrap px-8 py-3 rounded-lg shadow-lg shadow-accent/10">
              Search
            </button>
          </form>

          <div className="flex flex-wrap gap-4 justify-center">
            {user?.role === 'recruiter' ? (
              <Link to="/recruiter/post-job" className="btn-primary text-lg py-3 px-10">Post a Job</Link>
            ) : (
              <Link to="/jobs" className="btn-primary text-lg py-3 px-10">Explore Jobs</Link>
            )}
            {!user && (
              <Link to="/register?role=recruiter" className="btn-outline text-lg py-3 px-10 rounded-lg hover:bg-white hover:text-primary transition-all">
                Hire Talent
              </Link>
            )}
            <button
              onClick={scrollToContact}
              className="btn-outline text-lg py-3 px-10 rounded-lg transition-all"
            >
              Contact Us
            </button>
          </div>
        </div>

        <Icon name="chevronDown" size={24} className="hero-scroll absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce opacity-50" />
      </section>

      {/* ─── Stats Band ───────────────────────────────────────────────────── */}
      <section className="section-band border-y border-accent/10 bg-white">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 divide-x divide-accent/20 text-muted">
          <StatCard value="2,400+" label="Verified Jobs" />
          <StatCard value="18k+" label="Elite Seekers" />
          <StatCard value="9,200+" label="Global Hires" />
          <StatCard value="500+" label="Top Companies" />
        </div>
      </section>

      {/* ─── Benefits ─────────────────────────────────────────────────────── */}
      <section className="py-24 px-4 max-w-7xl mx-auto">
        <p className="section-title">The KAIROS Edge</p>
        <div className="gold-divider" />
        <p className="section-subtitle">A professional ecosystem designed for precision hiring and career advancement.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit) => (
            <div key={benefit.title} className="card p-6 group hover:border-accent transition-all">
              <div className="icon-tile mb-4 group-hover:scale-110 transition-transform">
                <Icon name={benefit.icon} size={21} />
              </div>
              <h3 className="font-semibold mb-2 text-primary">{benefit.title}</h3>
              <p className="text-sm leading-relaxed text-muted">{benefit.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ─── Categories ───────────────────────────────────────────────────── */}
      <section className="section-band py-24 px-4 bg-gray-50 border-y border-gray-100">
        <div className="max-w-7xl mx-auto">
          <p className="section-title">Industry Specializations</p>
          <div className="gold-divider" />
          <p className="section-subtitle">Find your niche in the most competitive sectors worldwide.</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {categories.map((category) => <CategoryCard key={category.label} {...category} />)}
          </div>
        </div>
      </section>

      {/* ─── The Journey ──────────────────────────────────────────────────── */}
      <section className="py-24 px-4 max-w-7xl mx-auto">
        <p className="section-title">The Journey</p>
        <div className="gold-divider" />
        <p className="section-subtitle">Your simple path from registration to that perfect professional match.</p>
        <div className="relative mt-12">
          <div className="process-line hidden lg:block absolute top-8 left-0 right-0 h-px bg-accent/20" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
            {steps.map((step) => (
              <div key={step.num} className="text-center relative">
                <div className="step-number mx-auto mb-4">{step.num}</div>
                <h3 className="font-semibold mb-2 text-primary">{step.title}</h3>
                <p className="text-sm text-muted">{step.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ─── Featured Jobs ────────────────────────────────────────────────── */}
      {featuredJobs.length > 0 && (
        <section className="section-band py-24 px-4 bg-accent/5">
          <div className="max-w-7xl mx-auto">
            <p className="section-title">Fresh Opportunities</p>
            <div className="gold-divider" />
            <p className="section-subtitle">The latest openings from our premium company partners.</p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-10">
              {featuredJobs.map((job) => <JobCard key={job._id} job={job} />)}
            </div>
            <div className="text-center">
              <Link to="/jobs" className="btn-primary text-base py-3 px-10 inline-flex items-center gap-2 rounded-full">
                Explore Marketplace <Icon name="arrowRight" size={15} />
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ─── Testimonials ─────────────────────────────────────────────────── */}
      <section className="py-24 px-4 max-w-7xl mx-auto">
        <p className="section-title">User Chronicles</p>
        <div className="gold-divider" />
        <p className="section-subtitle">Hear from the professionals and hiring teams transforming their futures.</p>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial) => <TestimonialCard key={testimonial.name} {...testimonial} />)}
        </div>
      </section>

      {/* ─── Call to Action ───────────────────────────────────────────────── */}
      <section className="cta-band py-24 px-4 text-center bg-primary text-white">
        <h2 className="font-cinzel font-black text-3xl md:text-5xl mb-6 text-accent uppercase tracking-tight">
          Your Moment is Now.
        </h2>
        <p className="mb-10 text-lg max-w-2xl mx-auto opacity-80 leading-relaxed">
          Whether you're looking to scale your team or skyrocket your career, KAIROS is the catalyst for your next big breakthrough.
        </p>
        <div className="flex gap-6 justify-center flex-wrap">
          <Link to="/register" className="btn-primary text-lg py-4 px-12 bg-accent text-primary font-bold hover:scale-105 transition-transform rounded-xl">
            Start Your Journey
          </Link>
          <Link to="/register?role=recruiter" className="btn-outline text-lg py-4 px-12 border-accent text-accent hover:bg-accent hover:text-primary transition-all font-bold rounded-xl">
            Hire with KAIROS
          </Link>
        </div>
      </section>

      {/* ─── Contact Section ──────────────────────────────────────────────── */}
      <section ref={contactRef} id="contact" className="py-24 px-4 border-t border-accent/10" style={{ background: 'var(--bg-secondary)' }}>
        <div className="max-w-7xl mx-auto">

          {/* Header */}
          <div className="text-center mb-14">
            <div className="display-badge text-[10px] font-black px-4 py-2 rounded-full mb-5 inline-flex items-center tracking-[0.2em]">
              <Icon name="mail" size={12} className="mr-2" /> GET IN TOUCH
            </div>
            <p className="section-title">Contact KAIROS</p>
            <div className="gold-divider" />
            <p className="section-subtitle">
              Have a question, partnership proposal, or feedback? Our team responds within 24 hours.
            </p>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "minmax(0,1fr) minmax(0,1.4fr)", gap: "2.5rem", alignItems: "start" }}>

            {/* Left Column — Info + Socials */}
            <div className="space-y-4">
              {contactInfo.map((info) => (
                <ContactInfoCard key={info.title} {...info} />
              ))}

              <div className="card p-5">
                <p className="text-[10px] font-black uppercase tracking-widest text-muted mb-4">Follow Us</p>
                <div className="flex gap-3">
                  {[
                    { icon: 'linkedin', href: '#', label: 'LinkedIn' },
                    { icon: 'github', href: '#', label: 'GitHub' },
                    { icon: 'globe', href: '#', label: 'Website' },
                    { icon: 'camera', href: '#', label: 'Instagram' },
                  ].map(({ icon, href, label }) => (
                    <a
                      key={label}
                      href={href}
                      title={label}
                      className="w-10 h-10 flex items-center justify-center rounded-xl border border-accent/20 text-accent hover:bg-accent hover:text-primary hover:border-accent transition-all"
                    >
                      <Icon name={icon} size={16} />
                    </a>
                  ))}
                </div>
              </div>

              <div className="card overflow-hidden h-44 relative flex items-center justify-center" style={{ background: 'var(--accent-light)' }}>
                <div className="text-center">
                  <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center mx-auto mb-3">
                    <Icon name="location" size={24} className="text-accent" />
                  </div>
                  <p className="text-sm font-bold text-primary">Bengaluru, Karnataka</p>
                  <p className="text-xs text-muted mt-0.5">India — 560001</p>
                  <a
                    href="https://maps.google.com/?q=Bengaluru,India"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[10px] font-black text-accent uppercase tracking-widest hover:underline mt-2 inline-flex items-center gap-1"
                  >
                    Open in Maps <Icon name="arrowRight" size={10} />
                  </a>
                </div>
              </div>
            </div>

            {/* Right Column — Contact Form */}
            <div>
              <div className="card p-8 shadow-xl" style={{ background: 'var(--bg-card)' }}>
                <h3 className="font-cinzel font-black text-xl mb-1 text-primary tracking-widest uppercase">
                  Send a Message
                </h3>
                <p className="text-xs text-muted mb-8">
                  Fill in the form and a KAIROS representative will reach out promptly.
                </p>

                <form onSubmit={handleContactSubmit} className="space-y-5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted block mb-1.5">
                        Full Name *
                      </label>
                      <input
                        name="name"
                        value={contactForm.name}
                        onChange={handleContactChange}
                        className="input-field"
                        placeholder="John Doe"
                        required
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black uppercase tracking-widest text-muted block mb-1.5">
                        Email Address *
                      </label>
                      <input
                        name="email"
                        type="email"
                        value={contactForm.email}
                        onChange={handleContactChange}
                        className="input-field"
                        placeholder="john@example.com"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-muted block mb-2">
                      I am a...
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {['Job Seeker', 'Recruiter', 'Other'].map((role) => (
                        <button
                          key={role}
                          type="button"
                          onClick={() => setContactForm((prev) => ({ ...prev, subject: role }))}
                          className={`py-2.5 text-xs font-bold rounded-lg border transition-all ${
                            contactForm.subject === role
                              ? 'bg-accent text-primary border-accent'
                              : 'border-accent/20 text-muted hover:border-accent/50 hover:text-primary'
                          }`}
                        >
                          {role}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase tracking-widest text-muted block mb-1.5">
                      Message *
                    </label>
                    <textarea
                      name="message"
                      value={contactForm.message}
                      onChange={handleContactChange}
                      className="input-field resize-none"
                      style={{ minHeight: '150px' }}
                      placeholder="Tell us how we can help — a question, a partnership idea, or platform feedback..."
                      required
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={contactSending}
                    className={`btn-primary w-full py-4 font-black uppercase tracking-[0.2em] flex items-center justify-center gap-3 ${
                      contactSending ? 'opacity-70 cursor-not-allowed' : ''
                    }`}
                  >
                    {contactSending ? (
                      <>
                        <span className="w-4 h-4 border-2 border-primary/40 border-t-primary rounded-full animate-spin" />
                        Sending...
                      </>
                    ) : (
                      <>
                        Send Message <Icon name="arrowRight" size={16} />
                      </>
                    )}
                  </button>

                  <p className="text-[10px] text-center text-muted pt-1">
                    We respect your privacy. Your information will never be shared with third parties.
                  </p>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;