import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import { jobsAPI, applicationsAPI, resumeAPI } from '../services/api';
import { useAuth } from '../context/AuthContext';
import Footer from '../components/Footer';
import Icon from '../components/Icon';
import Loader from '../components/Loader';
import Navbar from '../components/Navbar';

const typeClass = (type = '') => {
  const normalized = type.toLowerCase().replace(/\s+/g, '-');
  return `job-type-${normalized || 'default'}`;
};

const JobDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isSeeker } = useAuth();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [showApplyForm, setShowApplyForm] = useState(false);
  const [resume, setResume] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await jobsAPI.getById(id);
        setJob(res.data.job);

        if (user && isSeeker) {
          const [appsRes, resumeRes] = await Promise.all([
            applicationsAPI.getMy(),
            resumeAPI.getMy(),
          ]);
          const alreadyApplied = appsRes.data.applications.some((a) => a.job?._id === id);
          setApplied(alreadyApplied);
          setResume(resumeRes.data.resume);
        }
      } catch {
        toast.error('Failed to load job listing');
        navigate('/jobs');
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [id, user, isSeeker, navigate]);

  const handleApply = async (e) => {
    e.preventDefault();
    if (!user) {
      toast.error('Please log in to apply');
      navigate('/login');
      return;
    }
    if (!isSeeker) {
      toast.error('Only job seekers can apply for roles');
      return;
    }

    setApplying(true);
    try {
      await applicationsAPI.apply({ jobId: id, coverLetter });
      setApplied(true);
      setShowApplyForm(false);
      toast.success('Application submitted successfully!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Application failed');
    } finally {
      setApplying(false);
    }
  };

  if (loading) return <Loader />;
  if (!job) return null;

  const company = job.createdBy?.companyDetails?.companyName || job.company;

  return (
    <div className="page-shell">
      <Navbar />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-24 pb-16">
        <Link
          to="/jobs"
          className="text-accent text-[10px] font-black uppercase tracking-[0.2em] mb-8 inline-flex items-center gap-2 hover:-translate-x-1 transition-transform"
        >
          <Icon name="arrowLeft" size={14} /> Back to Listings
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="card p-8 bg-white shadow-lg">
              <div className="flex items-start gap-5 mb-6">
                <div className="job-detail-company company-mark bg-accent/10 text-accent font-black text-2xl flex-shrink-0 flex items-center justify-center rounded-2xl border border-accent/20 w-16 h-16">
                  {company?.charAt(0)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <h1 className="font-cinzel font-black text-2xl text-primary leading-tight">
                      {job.title}
                    </h1>
                    {job.isVerified && (
                      <span className="text-[8px] bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-black uppercase flex items-center gap-1">
                        <Icon name="check" size={8} /> Verified
                      </span>
                    )}
                  </div>
                  <p className="font-bold text-accent text-base mb-3">{company}</p>
                  <div className="flex flex-wrap gap-4 text-xs text-muted font-medium">
                    <span className="flex items-center gap-1.5"><Icon name="location" size={13} /> {job.location}</span>
                    <span className="flex items-center gap-1.5"><Icon name="briefcase" size={13} /> {job.experience}</span>
                    {job.salary && job.salary !== 'Not disclosed' && (
                      <span className="flex items-center gap-1.5"><Icon name="currency" size={13} /> {job.salary}</span>
                    )}
                    <span className="flex items-center gap-1.5"><Icon name="users" size={13} /> {job.applicationsCount || 0} applicants</span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 pt-4 border-t border-accent/10">
                <span className={`job-type ${typeClass(job.type)} text-xs font-bold px-3 py-1 rounded-full`}>
                  {job.type}
                </span>
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-accent/10 text-accent border border-accent/20">
                  {job.category}
                </span>
                {job.deadline && (
                  <span className="text-xs font-bold px-3 py-1 rounded-full bg-orange-50 text-orange-600 border border-orange-100 flex items-center gap-1">
                    <Icon name="calendar" size={11} />
                    Deadline: {new Date(job.deadline).toLocaleDateString()}
                  </span>
                )}
              </div>
            </div>

            {job.description && (
              <div className="card p-8 bg-white">
                <h2 className="font-cinzel font-bold text-sm text-accent uppercase tracking-[0.2em] border-b border-accent/10 pb-3 mb-5">
                  About This Role
                </h2>
                <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-line">
                  {job.description}
                </p>
              </div>
            )}

            {job.requirements?.length > 0 && (
              <div className="card p-8 bg-white">
                <h2 className="font-cinzel font-bold text-sm text-accent uppercase tracking-[0.2em] border-b border-accent/10 pb-3 mb-5">
                  Requirements
                </h2>
                <ul className="space-y-2.5">
                  {job.requirements.map((req, i) => (
                    <li key={i} className="flex items-start gap-3 text-sm text-gray-700">
                      <Icon name="check" size={16} className="text-accent flex-shrink-0 mt-0.5" />
                      {req}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {job.skills?.length > 0 && (
              <div className="card p-8 bg-white">
                <h2 className="font-cinzel font-bold text-sm text-accent uppercase tracking-[0.2em] border-b border-accent/10 pb-3 mb-5">
                  Tech Stack & Skills
                </h2>
                <div className="flex flex-wrap gap-2">
                  {job.skills.map((skill) => (
                    <span key={skill} className="skill-pill text-xs font-bold px-3 py-1.5 rounded-full border">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-5">
            <div className="card p-6 bg-white sticky top-24">
              <h3 className="font-cinzel font-bold text-[10px] text-accent uppercase tracking-[0.25em] border-b border-accent/10 pb-3 mb-5">
                Express Interest
              </h3>

              {!user ? (
                <div className="space-y-3">
                  <p className="text-xs text-muted leading-relaxed">
                    Sign in to apply for this role and track your application.
                  </p>
                  <Link to="/login" className="btn-primary w-full text-center text-sm py-3 block">
                    Sign In to Apply
                  </Link>
                  <Link to="/register" className="btn-outline w-full text-center text-sm py-3 block">
                    Create Account
                  </Link>
                </div>
              ) : applied ? (
                <div className="success-panel p-4 rounded-xl text-center">
                  <Icon name="checkCircle" size={28} className="mx-auto mb-2 text-success" />
                  <p className="font-bold text-sm text-success">Application Submitted</p>
                  <p className="text-xs text-muted mt-1">Track progress in your dashboard.</p>
                  <Link to="/dashboard" className="text-[10px] font-black text-accent uppercase tracking-widest mt-3 block hover:underline">
                    View Dashboard →
                  </Link>
                </div>
              ) : isSeeker ? (
                <>
                  {!resume && (
                    <div className="warning-panel p-3 rounded-lg mb-4 text-xs">
                      <p className="font-bold text-warning">Resume Required</p>
                      <Link to="/resume" className="text-accent font-bold underline">Upload your resume</Link> first.
                    </div>
                  )}

                  {!showApplyForm ? (
                    <button
                      onClick={() => setShowApplyForm(true)}
                      className="btn-primary w-full py-3 text-sm font-bold"
                    >
                      Apply Now
                    </button>
                  ) : (
                    <form onSubmit={handleApply} className="space-y-4">
                      <div>
                        <label className="form-label">Strategy Statement</label>
                        <textarea
                          value={coverLetter}
                          onChange={(e) => setCoverLetter(e.target.value)}
                          className="input-field min-h-[120px] resize-none text-sm"
                          placeholder="Tell the recruiter why you're the right fit..."
                        />
                      </div>

                      {resume ? (
                        <div className="flex items-center gap-2 p-3 bg-green-50 rounded-lg border border-green-100">
                          <Icon name="document" size={14} className="text-green-600" />
                          <span className="text-[10px] font-bold text-green-700 truncate">{resume.originalName}</span>
                        </div>
                      ) : (
                        <p className="text-[10px] text-orange-600 italic">No resume attached. Your profile will be sent instead.</p>
                      )}

                      <div className="flex gap-2">
                        <button type="submit" disabled={applying} className="btn-primary flex-1 py-3 text-sm font-bold">
                          {applying ? 'Submitting...' : 'Submit Application'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setShowApplyForm(false)}
                          className="btn-outline px-4 py-3 text-sm"
                        >
                          Cancel
                        </button>
                      </div>
                    </form>
                  )}
                </>
              ) : (
                <p className="text-xs text-muted italic text-center py-4">
                  {user.role === 'recruiter'
                    ? 'Recruiters cannot apply for jobs.'
                    : 'Admins cannot apply for jobs.'}
                </p>
              )}
            </div>

            <div className="card p-6 bg-white">
              <h3 className="font-cinzel font-bold text-[10px] text-accent uppercase tracking-[0.25em] border-b border-accent/10 pb-3 mb-4">
                Company Info
              </h3>
              <div className="flex items-center gap-3 mb-3">
                <div className="company-mark bg-accent/10 text-accent font-black">{company?.charAt(0)}</div>
                <div>
                  <p className="font-bold text-sm text-primary">{company}</p>
                  {job.createdBy?.companyDetails?.website && (
                    <a
                      href={job.createdBy.companyDetails.website}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-[10px] text-accent font-bold hover:underline"
                    >
                      Visit website
                    </a>
                  )}
                </div>
              </div>
              {job.createdBy?.companyDetails?.industry && (
                <p className="text-[10px] text-muted font-medium">
                  Industry: <span className="text-primary font-bold">{job.createdBy.companyDetails.industry}</span>
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default JobDetail;
