import { Link } from 'react-router-dom';
import Navbar from '../components/Navbar';
import Icon from '../components/Icon';

const NotFound = () => (
  <div className="page-shell">
    <Navbar />
    <div className="flex flex-col items-center justify-center min-h-screen text-center px-4 pt-16">
      <div className="not-found-code font-cinzel font-black text-8xl md:text-9xl mb-4 text-accent/20">404</div>
      <h1 className="font-cinzel font-bold text-3xl mb-3 text-primary uppercase tracking-widest">Moment Not Found</h1>
      <p className="mb-10 max-w-sm text-sm text-muted italic">The opportunity you're looking for doesn't exist or has moved across time.</p>
      
      <div className="flex gap-4 flex-wrap justify-center">
        <Link to="/" className="btn-primary py-4 px-10 font-bold uppercase text-[10px] tracking-widest shadow-gold">
           Return Home
        </Link>
        <Link to="/jobs" className="btn-outline py-4 px-10 font-bold uppercase text-[10px] tracking-widest border-accent text-accent">
           Marketplace
        </Link>
      </div>
    </div>
  </div>
);

export default NotFound;