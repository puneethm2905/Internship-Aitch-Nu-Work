import { Link } from 'react-router-dom';
import Icon from './Icon';
import { useAuth } from '../context/AuthContext'; // Import role logic[cite: 35]

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const { user } = useAuth();
  
  const isRecruiter = user?.role === 'recruiter';

  return (
    <footer className="footer mt-20 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="brand-mark footer-brand-mark">K</div>
              <span className="brand-name footer-brand-name">KAIROS</span>
            </div>
            <p className="text-sm italic mb-4 text-muted text-accent font-cinzel">LUCK MEETS OPPORTUNITY</p>
            <div className="flex gap-3">
              {[['LinkedIn', 'linkedin'], ['Twitter', 'globe'], ['GitHub', 'github'], ['Instagram', 'camera']].map(([label, icon]) => (
                <a key={label} href="#" className="social-link" title={label} aria-label={label}>
                  <Icon name={icon} size={15} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="footer-heading">Platform</h4>
            <ul className="space-y-2 text-sm">
              {[['/', 'Home'], ['/jobs', 'Browse Jobs'], ['/register', 'Seeker Registration'], ['/register?role=recruiter', 'Company Registration']].map(([to, label]) => (
                <li key={to}><Link to={to} className="footer-link">{label}</Link></li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="footer-heading">{isRecruiter ? 'Recruiters' : 'Job Seekers'}</h4>
            <ul className="space-y-2 text-sm">
              {isRecruiter ? (
                // Recruiter Specific Links[cite: 33]
                <>
                  <li><Link to="/recruiter/dashboard" className="footer-link">Talent Dashboard</Link></li>
                  <li><Link to="/recruiter/post-job" className="footer-link">Post a Listing</Link></li>
                  <li><Link to="/profile" className="footer-link">Company Profile</Link></li>
                </>
              ) : (
                // Seeker Specific Links[cite: 40]
                <>
                  <li><Link to="/dashboard" className="footer-link">My Applications</Link></li>
                  <li><Link to="/profile" className="footer-link">Manage Profile</Link></li>
                  <li><Link to="/resume" className="footer-link">Resume Settings</Link></li>
                </>
              )}
            </ul>
          </div>

          <div>
            <h4 className="footer-heading">Administration</h4>
            <ul className="space-y-2 text-sm text-muted">
              <li><Icon name="location" size={14} className="inline mr-2"/> Bengaluru, India</li>
              <li><Icon name="mail" size={14} className="inline mr-2"/> support@kairos.careers</li>
              <li className="pt-2">
                <Link to="/admin/login" className="footer-link footer-link-accent inline-flex items-center gap-1 font-semibold">
                  Admin Portal <Icon name="arrowRight" size={13} />
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="footer-bottom pt-6 flex flex-col sm:flex-row justify-between items-center gap-2 text-xs border-t border-gray-100">
          <span>&copy; {currentYear} KAIROS Portal. All rights reserved.</span>
          <span>Built with the MERN Stack</span>
        </div>
      </div>
    </footer>
  );
};

export default Footer;