/**
 * Standardized StatusChip Component.
 * Synchronizes backend application states with frontend visual indicators[cite: 13].
 */
const StatusChip = ({ status }) => {
  // Normalize to lowercase for consistency with the MongoDB Application model.
  const normalizedStatus = status?.toLowerCase();

  /**
   * CSS Class Mapping
   * Maps backend enums to specific Tailwind/Global CSS classes[cite: 13].
   */
  const classMap = {
    'applied': 'chip-pending',        // Initial submission state[cite: 13]
    'under-review': 'chip-reviewed',  // Recruiter is actively evaluating[cite: 18]
    'shortlisted': 'chip-shortlisted', // Candidate passed initial screening[cite: 13, 18]
    'rejected': 'chip-rejected',       // Candidate no longer under consideration[cite: 13]
    'hired': 'chip-hired',            // Successful placement
    'pending': 'chip-pending',        // Fallback for legacy data
  };

  /**
   * Label Formatter
   * Converts 'under-review' to 'Under Review' for professional display.
   */
  const formatText = (text) => {
    if (!text) return 'Unknown';
    return text
      .split('-')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  return (
    <span className={`status-chip ${classMap[normalizedStatus] || 'chip-pending'} inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold uppercase tracking-wider transition-colors`}>
      {formatText(normalizedStatus)}
    </span>
  );
};

export default StatusChip;