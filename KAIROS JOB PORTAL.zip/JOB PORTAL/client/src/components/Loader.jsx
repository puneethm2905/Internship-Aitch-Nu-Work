const Loader = ({ fullScreen = true }) => {
  if (fullScreen) {
    return (
      <div className="loader-screen">
        <div className="text-center">
          <div className="loader-ring loader-ring-lg" />
          {/* Maintained brand styling for consistency[cite: 38] */}
          <p className="font-cinzel text-lg text-accent mt-4 tracking-widest">KAIROS</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex justify-center py-8">
      <div className="loader-ring loader-ring-sm" />
    </div>
  );
};

export default Loader;