import { Link } from 'react-router-dom';
import Icon from './Icon';
import { useAuth } from '../context/AuthContext';

const typeClass = (type = '') => {
  const normalized = type.toLowerCase().replace(/\s+/g, '-');
  return `job-type-${normalized || 'default'}`;
};

const JobCard = ({ job, onDelete, onEdit }) => {
  const { user, isAdmin } = useAuth();

  // Determine ownership for management privileges
  const isOwner = user && (user.id === job.createdBy || user.id === job.createdBy?._id || isAdmin);
  
  return (
    <div className="card p-6 h-full flex flex-col clickable-card relative group">
      {/* Background link for easy navigation for seekers */}
      <Link to={`/jobs/${job._id}`} className="absolute inset-0 z-0" aria-label="View job details" />

      <div className="relative z-10 pointer-events-none">
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <div className="company-mark">
              {job.company?.charAt(0) || job.createdBy?.companyDetails?.companyName?.charAt(0)}
            </div>
            {/* New: Marketplace Verification Badge */}
            {job.isVerified && (
              <div className="flex items-center gap-1 text-[10px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full border border-blue-100">
                <Icon name="check" size={10} /> VERIFIED
              </div>
            )}
          </div>
          <span className={`job-type ${typeClass(job.type)} text-xs font-semibold px-2 py-1 rounded-full`}>
            {job.type}
          </span>
        </div>

        <h3 className="font-semibold text-base mb-1 line-clamp-2 text-primary">{job.title}</h3>
        <p className="text-sm mb-3 text-accent">
          {job.company || job.createdBy?.companyDetails?.companyName}
        </p>

        {/* Detailed Metadata */}
        <div className="flex flex-wrap gap-3 text-xs mb-4 text-muted">
          <span className="inline-flex items-center gap-1">
            <Icon name="location" size={14} /> {job.location}
          </span>
          <span className="inline-flex items-center gap-1">
            <Icon name="clock" size={14} /> {job.experience}
          </span>
          {job.salary && job.salary !== 'Not disclosed' && (
            <span className="inline-flex items-center gap-1">
              <Icon name="currency" size={14} /> {job.salary}
            </span>
          )}
        </div>

        {/* Skills Preview[cite: 15] */}
        {job.skills?.length > 0 && (
          <div className="flex flex-wrap gap-1 mb-4">
            {job.skills.slice(0, 3).map((skill) => (
              <span key={skill} className="skill-pill text-xs px-2 py-1 rounded">
                {skill}
              </span>
            ))}
            {job.skills.length > 3 && (
              <span className="text-xs px-2 py-1 rounded text-muted">
                +{job.skills.length - 3}
              </span>
            )}
          </div>
        )}
      </div>

      <div className="mt-auto flex items-center justify-between text-xs text-muted relative z-10">
        <span>{job.applicationsCount || 0} applicants</span>
        
        {/* Contextual Action Buttons[cite: 15] */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {isOwner ? (
            <>
              <button 
                onClick={(e) => { e.preventDefault(); onEdit(job); }}
                className="action-pill font-medium px-3 py-1 rounded-full inline-flex items-center gap-1 hover:bg-gray-100"
                title="Edit Job"
              >
                <Icon name="edit" size={13} /> Edit
              </button>
              <button 
                onClick={(e) => { e.preventDefault(); onDelete(job._id); }}
                className="action-pill font-medium px-3 py-1 rounded-full inline-flex items-center gap-1 bg-red-50 text-red-600 hover:bg-red-100 border border-red-100"
                title="Delete Job"
              >
                <Icon name="trash" size={13} />
              </button>
            </>
          ) : (
            <Link 
              to={`/jobs/${job._id}`}
              className="action-pill font-medium px-4 py-1.5 rounded-full inline-flex items-center gap-1 bg-primary text-white"
            >
              View & Apply <Icon name="arrowRight" size={13} />
            </Link>
          )}
        </div>
      </div>
    </div>
  );
};

export default JobCard;