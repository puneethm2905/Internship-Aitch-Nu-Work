import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import Icon from './Icon';

const Navbar = () => {
  const { user, logout, isAdmin } = useAuth();
  const { theme, setTheme, THEMES } = useTheme();
  const [menuOpen, setMenuOpen] = useState(false);
  const [themeOpen, setThemeOpen] = useState(false);
  const [authOpen, setAuthOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const themeRef = useRef(null);
  const authRef = useRef(null);

  // Core Role Detection logic for navigation
  const isRecruiter = user?.role === 'recruiter';
  const isSeeker = user?.role === 'seeker';

  useEffect(() => {
    const handler = (event) => {
      if (themeRef.current && !themeRef.current.contains(event.target)) setThemeOpen(false);
      if (authRef.current && !authRef.current.contains(event.target)) setAuthOpen(false);
    };

    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigate('/');
  };

  /**
   * Dynamic Link Matrix
   * Automatically populates based on authenticated role.
   */
  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/jobs', label: 'Explore Jobs' },
    // Seeker-Specific View
    ...(isSeeker
      ? [
          { to: '/dashboard', label: 'My Applications' },
          { to: '/profile', label: 'Professional Profile' },
        ]
      : []),
    // Recruiter-Specific View
    ...(isRecruiter
      ? [
          { to: '/recruiter/dashboard', label: 'Hiring Dashboard' },
          { to: '/recruiter/post-job', label: 'Post a Job' },
        ]
      : []),
    // Administrative Access[cite: 26]
    ...(isAdmin ? [{ to: '/admin', label: 'Admin Panel' }] : []),
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <nav className="navbar">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="brand-link">
            <div className="brand-mark">K</div>
            <span className="brand-name">KAIROS</span>
          </Link>

          {/* Desktop Primary Navigation[cite: 26] */}
          <div className="hidden md:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className={`nav-link ${isActive(link.to) ? 'nav-link-active' : ''}`}
              >
                {link.label}
              </Link>
            ))}
          </div>

          <div className="hidden md:flex items-center gap-3">
            {/* Theme Selector Component */}
            <div ref={themeRef} className="relative">
              <button
                type="button"
                onClick={() => setThemeOpen((open) => !open)}
                className="icon-button"
                title="Change appearance"
              >
                <Icon name="palette" size={18} />
              </button>

              {themeOpen && (
                <div className="dropdown theme-dropdown">
                  {THEMES.map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setTheme(item.id);
                        setThemeOpen(false);
                      }}
                      className={`dropdown-item ${theme === item.id ? 'dropdown-item-active' : ''}`}
                    >
                      <Icon name={item.icon} size={14} />
                      <span>{item.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {user ? (
              /* Authenticated User Actions[cite: 26] */
              <div ref={authRef} className="relative">
                <button
                  type="button"
                  onClick={() => setAuthOpen((open) => !open)}
                  className="user-menu-button"
                >
                  <span className="avatar-mark">{user.name?.charAt(0).toUpperCase()}</span>
                  {user.name?.split(' ')[0]}
                </button>

                {authOpen && (
                  <div className="dropdown auth-dropdown">
                    {isSeeker && (
                      <>
                        <Link to="/profile" onClick={() => setAuthOpen(false)} className="dropdown-link">
                          View Profile
                        </Link>
                        <Link to="/resume" onClick={() => setAuthOpen(false)} className="dropdown-link">
                          Manage Resume
                        </Link>
                      </>
                    )}
                    {isRecruiter && (
                      <>
                        <Link to="/profile" onClick={() => setAuthOpen(false)} className="dropdown-link">
                          Company Profile
                        </Link>
                        <Link to="/recruiter/dashboard" onClick={() => setAuthOpen(false)} className="dropdown-link">
                          Track Applicants
                        </Link>
                      </>
                    )}
                    <div className="border-t my-1 border-gray-100"></div>
                    <button type="button" onClick={handleLogout} className="dropdown-link danger-link">
                      Sign Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              /* Guest Quick-Start[cite: 26] */
              <div ref={authRef} className="relative">
                <button type="button" onClick={() => setAuthOpen((open) => !open)} className="btn-primary text-sm py-2 px-4 text-white">
                  Get Started
                </button>

                {authOpen && (
                  <div className="dropdown auth-dropdown">
                    <Link to="/register" onClick={() => setAuthOpen(false)} className="dropdown-link">
                      Find a Job
                    </Link>
                    <Link to="/register?role=recruiter" onClick={() => setAuthOpen(false)} className="dropdown-link">
                      Hire Talent
                    </Link>
                    <div className="border-t my-1 border-gray-100"></div>
                    <Link to="/login" onClick={() => setAuthOpen(false)} className="dropdown-link">
                      Sign In
                    </Link>
                    <Link to="/admin/login" onClick={() => setAuthOpen(false)} className="dropdown-link dropdown-link-accent">
                      Admin Portal
                    </Link>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Mobile Interaction Trigger */}
          <button
            type="button"
            className="mobile-menu-button"
            onClick={() => setMenuOpen((open) => !open)}
          >
            <Icon name={menuOpen ? 'close' : 'menu'} size={24} />
          </button>
        </div>
      </div>

      {/* Mobile Sidebar Navigation */}
      {menuOpen && (
        <div className="mobile-menu">
          {navLinks.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              onClick={() => setMenuOpen(false)}
              className={`mobile-nav-link ${isActive(link.to) ? 'nav-link-active' : ''}`}
            >
              {link.label}
            </Link>
          ))}

          {user ? (
            <button type="button" onClick={handleLogout} className="mt-3 w-full btn-outline text-sm py-2">
              Sign Out
            </button>
          ) : (
            <div className="flex flex-col gap-2 mt-3">
              <Link to="/login" className="btn-outline text-sm py-2 text-center">Login</Link>
              <Link to="/register" className="btn-primary text-sm py-2 text-center text-white">Register</Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;