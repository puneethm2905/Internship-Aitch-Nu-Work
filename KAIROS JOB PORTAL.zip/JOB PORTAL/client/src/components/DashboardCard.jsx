import Icon from './Icon';

/**
 * Enhanced DashboardCard component to support multi-role statistics.
 * Used across Seeker, Recruiter, and Admin dashboards.
 * 
 * @param {string} icon - Name of the icon from Icon.jsx.
 * @param {string} label - The descriptive title (e.g., "Active Listings").
 * @param {string|number} value - The main statistic.
 * @param {string} tone - Color theme ('accent', 'primary', 'success', 'danger', 'warning').
 * @param {number} trend - Percentage change for growth monitoring.
 * @param {string} subtitle - Optional context (e.g., "Verified this week").
 */
const DashboardCard = ({ 
  icon = 'dashboard', 
  label, 
  value = 0, 
  tone = 'accent', 
  trend,
  subtitle 
}) => {
  
  // Dynamic color mapping for visual consistency
  const toneColorClass = {
    accent: 'text-accent',
    primary: 'text-primary',
    success: 'text-green-600',
    danger: 'text-red-600',
    warning: 'text-yellow-600'
  }[tone] || 'text-accent';

  // Corresponding background tile class from global.css
  const iconBgClass = `stat-icon-${tone}`;

  return (
    <div className="card p-6 static-card h-full flex flex-col justify-between transition-transform hover:scale-[1.01] border border-gray-100">
      <div className="flex items-center justify-between mb-6">
        {/* Visual Anchor: Icon Tile */}
        <div className={`icon-tile ${iconBgClass} flex items-center justify-center rounded-xl p-3`}>
          <Icon name={icon} size={22} />
        </div>
        
        {/* Trend Indicator: Growth or Decline Logic */}
        {trend !== undefined && (
          <div className={`flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-full ${
            trend >= 0 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
          }`}>
            <Icon name={trend >= 0 ? 'arrowUp' : 'arrowDown'} size={10} />
            <span>{Math.abs(trend)}%</span>
          </div>
        )}
      </div>

      <div>
        {/* Main Statistic Display */}
        <div className={`text-3xl font-bold tracking-tight mb-1 ${toneColorClass}`}>
          {typeof value === 'number' ? value.toLocaleString() : value}
        </div>
        
        {/* Metadata and Context */}
        <div className="text-sm font-semibold text-gray-800 uppercase tracking-wide">{label}</div>
        
        {/* ATS Context: Secondary status information (e.g., "Shortlisted") */}
        {subtitle && (
          <div className="text-xs text-muted mt-1.5 font-medium flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-gray-300"></span>
            {subtitle}
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardCard;