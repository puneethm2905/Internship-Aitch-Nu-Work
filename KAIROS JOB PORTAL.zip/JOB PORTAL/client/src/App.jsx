import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { ProtectedRoute, AdminRoute, GuestRoute } from './routes/ProtectedRoute';

import SplashScreen from './pages/SplashScreen';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import AdminLogin from './pages/AdminLogin';
import Dashboard from './pages/Dashboard';
import Profile from './pages/Profile';
import AdminPanel from './pages/AdminPanel';
import JobList from './pages/JobList';
import JobDetail from './pages/JobDetail';
import Apply from './pages/Apply';
import ResumeUpload from './pages/ResumeUpload';
import RecruiterDashboard from './pages/RecruiterDashboard';
import PostJob from './pages/PostJob';
import NotFound from './pages/NotFound';

function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="bottom-center" toastOptions={{ className: 'toast-root', duration: 3500 }} />

          <Routes>
            <Route path="/splash" element={<SplashScreen />} />

            <Route path="/" element={<Home />} />
            <Route path="/jobs" element={<JobList />} />
            <Route path="/jobs/:id" element={<JobDetail />} />

            <Route path="/login" element={<GuestRoute><Login /></GuestRoute>} />
            <Route path="/register" element={<GuestRoute><Register /></GuestRoute>} />
            <Route path="/admin/login" element={<GuestRoute><AdminLogin /></GuestRoute>} />

            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />

            <Route path="/dashboard" element={
              <ProtectedRoute allowedRoles={['seeker']}><Dashboard /></ProtectedRoute>
            } />
            <Route path="/apply/:id" element={
              <ProtectedRoute allowedRoles={['seeker']}><Apply /></ProtectedRoute>
            } />
            <Route path="/resume" element={
              <ProtectedRoute allowedRoles={['seeker']}><ResumeUpload /></ProtectedRoute>
            } />

            <Route path="/recruiter/dashboard" element={
              <ProtectedRoute allowedRoles={['recruiter']}><RecruiterDashboard /></ProtectedRoute>
            } />
            <Route path="/recruiter/post-job" element={
              <ProtectedRoute allowedRoles={['recruiter']}><PostJob /></ProtectedRoute>
            } />
            <Route path="/recruiter/edit-job/:id" element={
              <ProtectedRoute allowedRoles={['recruiter']}><PostJob /></ProtectedRoute>
            } />

            <Route path="/admin" element={<AdminRoute><AdminPanel /></AdminRoute>} />
            <Route path="/admin/:section" element={<AdminRoute><AdminPanel /></AdminRoute>} />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
