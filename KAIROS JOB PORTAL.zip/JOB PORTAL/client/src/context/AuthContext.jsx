import { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('kairos-token');
    const stored = localStorage.getItem('kairos-user');

    if (token && stored) {
      try {
        const userData = JSON.parse(stored);
        setUser(userData);
        api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
      } catch (error) {
        console.error('Session restore failed:', error);
        logout();
      }
    }
    setLoading(false);
  }, []);

  const login = (token, userData) => {
    localStorage.setItem('kairos-token', token);
    localStorage.setItem('kairos-user', JSON.stringify(userData));
    api.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    setUser(userData);
  };

  const logout = () => {
    localStorage.removeItem('kairos-token');
    localStorage.removeItem('kairos-user');
    delete api.defaults.headers.common['Authorization'];
    setUser(null);
  };

  const isAdmin = user?.role === 'admin';
  const isRecruiter = user?.role === 'recruiter';
  const isSeeker = user?.role === 'seeker';

  return (
    <AuthContext.Provider value={{ user, login, logout, loading, isAdmin, isRecruiter, isSeeker }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
