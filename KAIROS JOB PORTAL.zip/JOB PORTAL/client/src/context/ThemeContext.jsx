import { createContext, useContext, useEffect, useState } from 'react';

const THEMES = [
  { id: 'gold-black', label: 'Classic Gold & Black', icon: 'diamond' },
  { id: 'ivory-gold', label: 'Light Ivory & Gold', icon: 'circle' },
];

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [theme, setTheme] = useState(() => {
    const savedTheme = localStorage.getItem('kairos-theme');
    // Default to 'gold-black' if no valid preference exists[cite: 28]
    return THEMES.some((item) => item.id === savedTheme) ? savedTheme : 'gold-black';
  });

  // Apply the theme attribute to the HTML element for global CSS targeting[cite: 28]
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('kairos-theme', theme);
  }, [theme]);

  return (
    <ThemeContext.Provider value={{ theme, setTheme, THEMES }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => useContext(ThemeContext);