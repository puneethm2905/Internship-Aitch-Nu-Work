import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import Loader from '../components/Loader';

export const ProtectedRoute = ({ children, allowedRoles }) => {
  const { user, loading } = useAuth();

  if (loading) return <Loader />;
  if (!user) return <Navigate to="/login" replace />;

  if (allowedRoles && !allowedRoles.includes(user.role)) {
    const fallbackMap = {
      admin: '/admin',
      recruiter: '/recruiter/dashboard',
      seeker: '/dashboard',
    };
    return <Navigate to={fallbackMap[user.role] || '/'} replace />;
  }

  return children;
};

export const AdminRoute = ({ children }) => {
  const { user, loading, isAdmin } = useAuth();

  if (loading) return <Loader />;
  if (!user || !isAdmin) return <Navigate to="/admin/login" replace />;

  return children;
};

export const GuestRoute = ({ children }) => {
  const { user, loading } = useAuth();

  if (loading) return <Loader />;

  if (user) {
    const dashboardMap = {
      admin: '/admin',
      recruiter: '/recruiter/dashboard',
      seeker: '/dashboard',
    };
    return <Navigate to={dashboardMap[user.role] || '/dashboard'} replace />;
  }

  return children;
};
