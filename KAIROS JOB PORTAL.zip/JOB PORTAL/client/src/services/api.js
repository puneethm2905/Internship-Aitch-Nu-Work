import axios from 'axios';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  headers: { 'Content-Type': 'application/json' },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('kairos-token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('kairos-token');
      localStorage.removeItem('kairos-user');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;

export const authAPI = {
  register: (data) => api.post('/auth/register', data),
  login: (data) => api.post('/auth/login', data),
  adminLogin: (data) => api.post('/auth/admin-login', data),
  me: () => api.get('/auth/me'),
};

export const jobsAPI = {
  getAll: (params) => api.get('/jobs', { params }),
  getById: (id) => api.get(`/jobs/${id}`),
  create: (data) => api.post('/jobs', data),
  update: (id, data) => api.put(`/jobs/${id}`, data),
  delete: (id) => api.delete(`/jobs/${id}`),
};

export const recruiterAPI = {
  getMyJobs: () => api.get('/recruiter/my-jobs'),
  getApplicants: () => api.get('/recruiter/applications'),
  updateApplicantStatus: (id, status) => api.put(`/recruiter/applications/${id}/status`, { status }),
  sendAptitudeTest: (id, data) => api.post(`/recruiter/applications/${id}/send-test`, data),
  sendInterviewInvite: (id, data) => api.post(`/recruiter/applications/${id}/send-interview`, data),
};

export const profileAPI = {
  get: () => api.get('/profile'),
  update: (data) => api.put('/profile', data),
  uploadAvatar: (formData) =>
    api.post('/profile/avatar', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
};

export const applicationsAPI = {
  apply: (data) => api.post('/applications', data),
  getMy: () => api.get('/applications/my'),
  getAll: () => api.get('/applications/all'),
  updateStatus: (id, status) => api.put(`/applications/${id}/status`, { status }),
};



export const resumeAPI = {
  upload: (formData) =>
    api.post('/resume/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  getMy: () => api.get('/resume/my'),
};

export const certificatesAPI = {
  upload: (formData) =>
    api.post('/certificates/upload', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    }),
  deleteFile: (filename) => api.delete(`/certificates/file/${filename}`),
};

export const adminAPI = {
  getStats: () => api.get('/admin/stats'),
  getUsers: (role) => api.get('/admin/users', { params: { role } }),
  getJobs: () => api.get('/admin/jobs'),
  verifyJob: (id) => api.patch(`/admin/jobs/${id}/verify`),
  deleteUser: (id) => api.delete(`/admin/users/${id}`),
};
