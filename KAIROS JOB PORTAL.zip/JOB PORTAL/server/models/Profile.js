const mongoose = require('mongoose');

const profileSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  bio: { type: String, default: '' },
  skills: [{ type: String }],
  education: [
    {
      institution: { type: String, required: true },
      degree: { type: String, required: true },
      field: { type: String },
      from: { type: Date },
      to: { type: Date },
      current: { type: Boolean, default: false },
    },
  ],
  experience: [
    {
      title: { type: String, required: true },
      company: { type: String, required: true },
      location: { type: String },
      from: { type: Date },
      to: { type: Date },
      current: { type: Boolean, default: false },
      description: { type: String },
    },
  ],
  links: {
    linkedin: { type: String, default: '' },
    github: { type: String, default: '' },
    portfolio: { type: String, default: '' },
  },
  certificates: [
    {
      title: { type: String, required: true },
      issuer: { type: String },
      issueDate: { type: Date },
      credentialUrl: { type: String },
      fileUrl: { type: String },
      filename: { type: String },
      description: { type: String },
    },
  ],
  updatedAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('Profile', profileSchema);
