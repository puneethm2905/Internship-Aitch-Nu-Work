const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true },
  resume: { type: mongoose.Schema.Types.ObjectId, ref: 'Resume' },
  coverLetter: { type: String, default: '' },
  status: {
    type: String,
    enum: ['applied', 'under-review', 'shortlisted', 'rejected'],
    default: 'applied',
  },
  appliedAt: { type: Date, default: Date.now },
});

applicationSchema.index({ user: 1, job: 1 }, { unique: true });

module.exports = mongoose.model('Application', applicationSchema);
