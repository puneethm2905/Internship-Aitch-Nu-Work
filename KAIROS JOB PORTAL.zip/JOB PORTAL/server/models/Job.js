const mongoose = require('mongoose');

const jobSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  company: { type: String, required: true, trim: true },
  location: { type: String, required: true, trim: true },
  type: {
    type: String,
    enum: ['Full-Time', 'Part-Time', 'Remote', 'Hybrid', 'Internship', 'Contract'],
    required: true,
  },
  category: {
    type: String,
    enum: ['Technology', 'Management', 'Marketing', 'Finance', 'Design', 'Healthcare', 'Education', 'Other'],
    required: true,
  },
  salary: { type: String, default: 'Not disclosed' },
  description: { type: String, required: true },
  requirements: [{ type: String }],
  skills: [{ type: String }],
  experience: { type: String, default: '0-1 years' },
  deadline: { type: Date },
  isActive: { type: Boolean, default: true },
  isVerified: { type: Boolean, default: false },
  applicationsCount: { type: Number, default: 0 },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  createdAt: { type: Date, default: Date.now },
});

jobSchema.index({ title: 'text', company: 'text', description: 'text', location: 'text' });

module.exports = mongoose.model('Job', jobSchema);
