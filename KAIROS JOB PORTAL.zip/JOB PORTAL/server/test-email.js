require('dotenv').config();
const nodemailer = require('nodemailer');

console.log('Testing SMTP connection...');
console.log('Host:', process.env.SMTP_HOST);
console.log('Port:', process.env.SMTP_PORT);
console.log('User:', process.env.SMTP_USER);
console.log('From:', process.env.MAIL_FROM);

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
  tls: { rejectUnauthorized: false },
});

transporter.verify((err, success) => {
  if (err) {
    console.error('\nSMTP FAILED:', err.message);
    console.log('\nTroubleshooting:');
    console.log('1. Check SMTP_PASS in .env is correct');
    console.log('2. Make sure your IP is authorized in Brevo Security settings');
    console.log('3. Try adding 0.0.0.0/0 in Brevo Security → Authorize IP');
  } else {
    console.log('\nSMTP CONNECTED ✓ — Sending test email...');

    transporter.sendMail({
      from: process.env.MAIL_FROM,
      to: process.env.MAIL_FROM,
      subject: 'KAIROS Email Test ✓',
      html: `
        <div style="font-family:sans-serif;max-width:500px;margin:auto;padding:32px;border:1px solid #e2e8f0;border-radius:12px;">
          <div style="background:#0f172a;padding:20px;text-align:center;border-radius:8px;margin-bottom:24px;">
            <span style="font-size:24px;font-weight:900;color:#ca9b20;letter-spacing:8px;">KAIROS</span>
          </div>
          <h2 style="color:#0f172a;">Email Service Working ✓</h2>
          <p style="color:#64748b;">Your SMTP configuration is correct. All email notifications in the KAIROS Job Portal will work properly.</p>
          <ul style="color:#475569;font-size:14px;line-height:2;">
            <li>Application confirmation emails ✓</li>
            <li>Status update notifications ✓</li>
            <li>Aptitude test invitations ✓</li>
            <li>Interview schedule emails ✓</li>
          </ul>
        </div>
      `,
    })
      .then(() => {
        console.log('\nEmail sent successfully ✓');
        console.log('Check your inbox at:', process.env.MAIL_FROM);
      })
      .catch((e) => {
        console.error('\nSend failed:', e.message);
      });
  }
});