require('dotenv').config();
const mongoose = require('mongoose');
const User = require('../models/User');
const Job = require('../models/Job');
const connectDB = require('../config/db');

/**
 * Database Seeder Logic
 * Initializes the system with a Root Admin and verified sample jobs.
 */
const seed = async () => {
  try {
    await connectDB();

    // 1. Initialize Admin Identity with the correct three-tier role
    const existingAdmin = await User.findOne({ email: 'admin@kairos.com' });
    let adminUser;

    if (!existingAdmin) {
      adminUser = await User.create({
        name: 'KAIROS Admin',
        email: 'admin@kairos.com',
        password: 'Admin@123',
        role: 'admin', // Enforces system-wide moderation privileges[cite: 30, 32]
      });
      console.log('✅ Admin identity established:', adminUser.email);
    } else {
      adminUser = existingAdmin;
      console.log('ℹ️  Admin identity already present.');
    }

    // 2. Initialize Marketplace Data[cite: 30, 32]
    const jobsExist = await Job.countDocuments();
    if (jobsExist === 0) {
      await Job.insertMany([
        {
          title: 'Senior Frontend Developer',
          company: 'Nexus Technologies',
          location: 'Bangalore, India',
          type: 'Full-Time',
          category: 'Technology',
          salary: '₹18-25 LPA',
          description: 'Join a high-growth team as a lead React engineer.',
          requirements: ['5+ years experience', 'React.js expert', 'TypeScript'],
          skills: ['React', 'TypeScript', 'Tailwind CSS'],
          experience: '5+ years',
          createdBy: adminUser._id, // Links listing to a valid creator[cite: 30, 32]
          isVerified: true // Pre-verified for immediate seeker visibility
        },
        {
          title: 'Product Manager',
          company: 'Innovate Corp',
          location: 'Mumbai, India',
          type: 'Full-Time',
          category: 'Management',
          salary: '₹20-30 LPA',
          description: 'Lead cross-functional teams and product strategy.',
          requirements: ['MBA preferred', '3+ years PM experience'],
          skills: ['Strategy', 'Agile', 'Roadmapping'],
          experience: '3-5 years',
          createdBy: adminUser._id,
          isVerified: true
        },
        {
          title: 'UX/UI Designer',
          company: 'Creative Studio',
          location: 'Remote',
          type: 'Remote',
          category: 'Design',
          salary: '₹12-18 LPA',
          description: 'Design intuitive interfaces for global SaaS products.',
          requirements: ['Figma expert', 'Strong portfolio'],
          skills: ['Figma', 'Prototyping', 'User Research'],
          experience: '2-4 years',
          createdBy: adminUser._id,
          isVerified: true
        },
        {
          title: 'Backend Engineer (Node.js)',
          company: 'DataFlow Inc',
          location: 'Hyderabad, India',
          type: 'Hybrid',
          category: 'Technology',
          salary: '₹15-22 LPA',
          description: 'Build scalable microservices and REST APIs.',
          requirements: ['Node.js', 'MongoDB', 'Docker'],
          skills: ['Node.js', 'Express', 'MongoDB'],
          experience: '3-5 years',
          createdBy: adminUser._id,
          isVerified: true
        },
        {
          title: 'Digital Marketing Specialist',
          company: 'BrandUp Agency',
          location: 'Delhi, India',
          type: 'Full-Time',
          category: 'Marketing',
          salary: '₹8-14 LPA',
          description: 'Drive growth through SEO and SEM strategies.',
          requirements: ['Google Ads certified', 'SEO expertise'],
          skills: ['SEO', 'Google Ads', 'Analytics'],
          experience: '2-4 years',
          createdBy: adminUser._id,
          isVerified: true
        },
        {
          title: 'Software Engineering Intern',
          company: 'StartUp Hub',
          location: 'Bangalore, India',
          type: 'Internship',
          category: 'Technology',
          salary: '₹25,000/month',
          description: 'Launch your career by working on real-world projects.',
          requirements: ['CS/IT student', 'Basic JS/React'],
          skills: ['JavaScript', 'React', 'Git'],
          experience: '0-1 years',
          createdBy: adminUser._id,
          isVerified: true
        },
      ]);
      console.log('✅ Marketplace seeded with verified listings.');
    } else {
      console.log('ℹ️  Marketplace already contains data.');
    }

    console.log('\n🎉 System initialization complete!');
    console.log('Credentials: admin@kairos.com / Admin@123\n');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seeding failed:', err.message);
    process.exit(1);
  }
};

seed();