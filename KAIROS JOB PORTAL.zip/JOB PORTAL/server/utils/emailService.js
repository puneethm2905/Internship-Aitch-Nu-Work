const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
  tls: { rejectUnauthorized: false },
});

transporter.verify((error) => {
  if (error) {
    console.error('SMTP connection failed:', error.message);
  } else {
    console.log('Email service ready');
  }
});

const BASE_URL = process.env.CLIENT_URL || 'http://localhost:5173';
const FROM = process.env.MAIL_FROM || 'noreply@kairos.com';

const emailHeader = (subtitle = '') => `
  <div style="background:#0f172a;padding:32px;text-align:center;">
    <div style="font-size:30px;font-weight:900;color:#ca9b20;letter-spacing:10px;font-family:Georgia,serif;">KAIROS</div>
    ${subtitle ? `<div style="font-size:11px;color:#94a3b8;letter-spacing:4px;margin-top:4px;text-transform:uppercase;">${subtitle}</div>` : ''}
  </div>
`;

const emailFooter = () => `
  <div style="border-top:1px solid #e2e8f0;padding:20px 32px;text-align:center;">
    <p style="color:#94a3b8;font-size:11px;margin:0;">Automated notification from KAIROS Job Portal. Do not reply to this email.</p>
  </div>
`;

const wrapEmail = (content) => `
  <div style="font-family:'Segoe UI',Arial,sans-serif;max-width:600px;margin:0 auto;background:#fff;border:1px solid #e2e8f0;border-radius:12px;overflow:hidden;">
    ${content}
  </div>
`;

const goldBtn = (text, href) => `
  <a href="${href}" style="display:inline-block;background:#0f172a;color:#ca9b20;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:700;font-size:12px;letter-spacing:2px;text-transform:uppercase;margin-top:8px;">${text}</a>
`;

const statusColors = {
  applied: '#d97706',
  'under-review': '#2563eb',
  shortlisted: '#16a34a',
  rejected: '#dc2626',
};

const statusLabels = {
  applied: 'Application Received',
  'under-review': 'Under Review',
  shortlisted: 'Shortlisted',
  rejected: 'Not Selected',
};

const statusMessages = {
  applied: 'Your application has been received and is pending review by the hiring team.',
  'under-review': 'The hiring team is actively reviewing your application. Stay tuned for updates.',
  shortlisted: 'Congratulations! You have been shortlisted for this role. The recruiter will contact you shortly with next steps.',
  rejected: 'Thank you for your interest. After careful consideration, the team has decided to move forward with other candidates. Keep applying — the right opportunity is ahead!',
};

const sendApplicationConfirmation = async (seekerEmail, recruiterEmail, jobTitle, seekerName, companyName) => {
  try {
    await transporter.sendMail({
      from: `"KAIROS Job Portal" <${FROM}>`,
      to: seekerEmail,
      subject: `Application Submitted — ${jobTitle}`,
      html: wrapEmail(`
        ${emailHeader('Application Confirmation')}
        <div style="padding:40px 32px;">
          <h2 style="color:#0f172a;margin:0 0 8px;font-size:22px;">You're in the pipeline!</h2>
          <p style="color:#64748b;font-size:14px;margin:0 0 24px;">
            Your application for <strong style="color:#0f172a;">${jobTitle}</strong>
            ${companyName ? ` at <strong style="color:#0f172a;">${companyName}</strong>` : ''} has been successfully submitted.
          </p>
          <div style="background:#f8fafc;border-radius:10px;padding:20px;margin-bottom:28px;border-left:4px solid #ca9b20;">
            <p style="margin:0;font-size:13px;color:#475569;line-height:1.7;">
              <strong>What happens next?</strong><br/>
              The recruiter will review your profile and resume. You will receive an email notification when your status changes — whether you're shortlisted, invited for an assessment, or scheduled for an interview.
            </p>
          </div>
          ${goldBtn('Track My Application', `${BASE_URL}/dashboard`)}
        </div>
        ${emailFooter()}
      `),
    });

    if (recruiterEmail) {
      await transporter.sendMail({
        from: `"KAIROS Job Portal" <${FROM}>`,
        to: recruiterEmail,
        subject: `New Applicant — ${jobTitle}`,
        html: wrapEmail(`
          ${emailHeader('New Application Alert')}
          <div style="padding:40px 32px;">
            <h2 style="color:#0f172a;margin:0 0 8px;">New Application Received</h2>
            <p style="color:#64748b;font-size:14px;margin:0 0 24px;">
              <strong style="color:#0f172a;">${seekerName}</strong> has applied for <strong style="color:#0f172a;">${jobTitle}</strong>.
            </p>
            <p style="color:#475569;font-size:13px;margin:0 0 24px;">
              Log in to your recruiter dashboard to review their profile, view their resume, and update their application status.
            </p>
            ${goldBtn('Review Applicant', `${BASE_URL}/recruiter/dashboard`)}
          </div>
          ${emailFooter()}
        `),
      });
    }

    console.log('Application confirmation emails sent');
  } catch (err) {
    console.error('Application confirmation email error:', err.message);
  }
};

const sendStatusEmail = async (seekerEmail, status, jobTitle, companyName = '') => {
  const color = statusColors[status] || '#64748b';
  const label = statusLabels[status] || status;
  const message = statusMessages[status] || 'Your application status has been updated.';

  try {
    await transporter.sendMail({
      from: `"KAIROS Job Portal" <${FROM}>`,
      to: seekerEmail,
      subject: `Application Update: ${jobTitle} — ${label}`,
      html: wrapEmail(`
        ${emailHeader('Application Status Update')}
        <div style="padding:40px 32px;">
          <h2 style="color:#0f172a;margin:0 0 8px;">Your Status Has Changed</h2>
          <p style="color:#64748b;font-size:14px;margin:0 0 28px;">
            For your application to <strong style="color:#0f172a;">${jobTitle}</strong>
            ${companyName ? ` at <strong style="color:#0f172a;">${companyName}</strong>` : ''}.
          </p>
          <div style="text-align:center;padding:24px;background:${color}10;border:1px solid ${color}30;border-radius:12px;margin-bottom:28px;">
            <p style="margin:0 0 10px;font-size:11px;color:${color};font-weight:700;letter-spacing:3px;text-transform:uppercase;">New Status</p>
            <div style="display:inline-block;background:${color}20;border:1px solid ${color}40;color:${color};padding:8px 20px;border-radius:20px;font-size:14px;font-weight:700;letter-spacing:2px;text-transform:uppercase;">${label}</div>
          </div>
          <p style="color:#475569;font-size:14px;line-height:1.7;margin:0 0 28px;">${message}</p>
          ${goldBtn('Open Dashboard', `${BASE_URL}/dashboard`)}
        </div>
        ${emailFooter()}
      `),
    });
    console.log(`Status email (${status}) sent to:`, seekerEmail);
  } catch (err) {
    console.error('Status email error:', err.message);
    throw err;
  }
};

const sendAptitudeTestInvite = async ({ seekerEmail, seekerName, jobTitle, companyName, testLink, testDeadline, instructions }) => {
  try {
    await transporter.sendMail({
      from: `"${companyName} via KAIROS" <${FROM}>`,
      to: seekerEmail,
      subject: `Assessment Invite — ${jobTitle} at ${companyName}`,
      html: wrapEmail(`
        ${emailHeader('Assessment Invitation')}
        <div style="padding:40px 32px;">
          <h2 style="color:#0f172a;margin:0 0 8px;">You've Been Invited to an Assessment</h2>
          <p style="color:#64748b;font-size:14px;margin:0 0 24px;">
            Dear <strong>${seekerName}</strong>, as part of the selection process for
            <strong style="color:#0f172a;">${jobTitle}</strong> at <strong style="color:#0f172a;">${companyName}</strong>,
            you are invited to complete an online aptitude test.
          </p>
          <div style="background:#f0fdf4;border:1px solid #86efac;border-radius:10px;padding:20px 24px;margin-bottom:24px;">
            <p style="margin:0 0 10px;font-size:12px;font-weight:700;color:#166534;letter-spacing:2px;text-transform:uppercase;">Assessment Details</p>
            ${testDeadline ? `<p style="margin:0 0 6px;font-size:13px;color:#15803d;"><strong>Deadline:</strong> ${testDeadline}</p>` : ''}
            ${instructions ? `<p style="margin:0;font-size:13px;color:#15803d;line-height:1.6;"><strong>Instructions:</strong> ${instructions}</p>` : ''}
          </div>
          <p style="color:#475569;font-size:13px;line-height:1.7;margin:0 0 24px;">
            Click the button below to begin. Ensure you are in a quiet environment with a stable internet connection before starting.
          </p>
          <a href="${testLink}" style="display:inline-block;background:#16a34a;color:#fff;padding:14px 36px;border-radius:8px;text-decoration:none;font-weight:700;font-size:12px;letter-spacing:2px;text-transform:uppercase;">Start Assessment →</a>
          <p style="color:#94a3b8;font-size:11px;margin-top:16px;">
            Link not working? Copy: <a href="${testLink}" style="color:#ca9b20;">${testLink}</a>
          </p>
        </div>
        ${emailFooter()}
      `),
    });
    console.log('Aptitude test invite sent to:', seekerEmail);
  } catch (err) {
    console.error('Aptitude test email error:', err.message);
    throw err;
  }
};

const sendInterviewInvite = async ({ seekerEmail, seekerName, jobTitle, companyName, interviewType, dateTime, location, meetingLink, contactPerson, additionalNotes }) => {
  const isRemote = interviewType === 'remote';

  try {
    await transporter.sendMail({
      from: `"${companyName} via KAIROS" <${FROM}>`,
      to: seekerEmail,
      subject: `Interview Scheduled — ${jobTitle} at ${companyName}`,
      html: wrapEmail(`
        ${emailHeader('Interview Invitation')}
        <div style="padding:40px 32px;">
          <h2 style="color:#0f172a;margin:0 0 8px;">Interview Invitation</h2>
          <p style="color:#64748b;font-size:14px;margin:0 0 24px;">
            Dear <strong>${seekerName}</strong>, congratulations! You are invited for an interview for
            <strong style="color:#0f172a;">${jobTitle}</strong> at <strong style="color:#0f172a;">${companyName}</strong>.
          </p>
          <div style="background:#eff6ff;border:1px solid #93c5fd;border-radius:10px;padding:24px;margin-bottom:24px;">
            <p style="margin:0 0 14px;font-size:12px;font-weight:700;color:#1d4ed8;letter-spacing:2px;text-transform:uppercase;">Interview Details</p>
            <table style="width:100%;border-collapse:collapse;font-size:13px;">
              <tr><td style="padding:5px 0;color:#374151;font-weight:600;width:140px;">Format</td><td style="color:#1d4ed8;">${isRemote ? '🌐 Remote / Video Call' : '🏢 Onsite'}</td></tr>
              <tr><td style="padding:5px 0;color:#374151;font-weight:600;">Date & Time</td><td style="color:#374151;">${dateTime}</td></tr>
              ${isRemote && meetingLink ? `<tr><td style="padding:5px 0;color:#374151;font-weight:600;">Meeting Link</td><td><a href="${meetingLink}" style="color:#2563eb;font-weight:600;">${meetingLink}</a></td></tr>` : ''}
              ${!isRemote && location ? `<tr><td style="padding:5px 0;color:#374151;font-weight:600;">Venue</td><td style="color:#374151;">${location}</td></tr>` : ''}
              ${contactPerson ? `<tr><td style="padding:5px 0;color:#374151;font-weight:600;">Contact</td><td style="color:#374151;">${contactPerson}</td></tr>` : ''}
            </table>
          </div>
          ${additionalNotes ? `
          <div style="background:#fefce8;border:1px solid #fde047;border-radius:10px;padding:16px 20px;margin-bottom:24px;">
            <p style="margin:0 0 6px;font-size:11px;font-weight:700;color:#854d0e;letter-spacing:2px;text-transform:uppercase;">Notes from Recruiter</p>
            <p style="margin:0;font-size:13px;color:#713f12;line-height:1.6;">${additionalNotes}</p>
          </div>` : ''}
          <p style="color:#475569;font-size:13px;line-height:1.7;margin:0 0 24px;">
            Please confirm your attendance by logging into your KAIROS dashboard. We look forward to meeting you!
          </p>
          ${goldBtn('Open My Dashboard', `${BASE_URL}/dashboard`)}
        </div>
        ${emailFooter()}
      `),
    });
    console.log('Interview invite sent to:', seekerEmail);
  } catch (err) {
    console.error('Interview invite email error:', err.message);
    throw err;
  }
};

module.exports = {
  sendApplicationConfirmation,
  sendStatusEmail,
  sendAptitudeTestInvite,
  sendInterviewInvite,
};
