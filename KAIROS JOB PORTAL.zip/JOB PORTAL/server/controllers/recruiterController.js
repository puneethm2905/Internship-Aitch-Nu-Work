const Job = require('../models/Job');
const Application = require('../models/Application');
const { sendStatusEmail } = require('../utils/emailService');

const getMyPostedJobs = async (req, res) => {
  try {
    const jobs = await Job.find({ createdBy: req.user.id }).sort({ createdAt: -1 });
    res.json({ success: true, jobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getJobApplicants = async (req, res) => {
  try {
    const myJobs = await Job.find({ createdBy: req.user.id }).select('_id');
    const jobIds = myJobs.map((job) => job._id);

    const applications = await Application.find({ job: { $in: jobIds } })
      .populate('user', 'name email phone')
      .populate('job', 'title company')
      .populate('resume', 'originalName fileUrl size uploadedAt')
      .sort({ appliedAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const updateApplicantStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const validStatuses = ['applied', 'under-review', 'shortlisted', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status value.' });
    }

    const application = await Application.findById(req.params.id)
      .populate('user', 'name email')
      .populate('job');

    if (!application) {
      return res.status(404).json({ success: false, message: 'Application not found.' });
    }

    if (application.job.createdBy.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    application.status = status;
    await application.save();

    try {
      await sendStatusEmail(
        application.user.email,
        status,
        application.job.title,
        application.job.company
      );
    } catch (emailErr) {
      console.error('Status notification failed:', emailErr.message);
    }

    res.json({ success: true, message: `Status updated to ${status}.`, application });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};


const sendAptitudeTest = async (req, res) => {
  try {
    const { testLink, testDeadline, instructions } = req.body;
    if (!testLink) {
      return res.status(400).json({ success: false, message: 'Test link is required.' });
    }

    const application = await Application.findById(req.params.id)
      .populate('user', 'name email')
      .populate('job');

    if (!application) {
      return res.status(404).json({ success: false, message: 'Application not found.' });
    }

    if (application.job.createdBy.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    const { sendAptitudeTestInvite } = require('../utils/emailService');
    await sendAptitudeTestInvite({
      seekerEmail: application.user.email,
      seekerName: application.user.name,
      jobTitle: application.job.title,
      companyName: application.job.company,
      testLink,
      testDeadline,
      instructions,
    });

    res.json({ success: true, message: 'Aptitude test invite sent successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const sendInterviewDetails = async (req, res) => {
  try {
    const { interviewType, dateTime, location, meetingLink, contactPerson, additionalNotes } = req.body;

    if (!dateTime || !interviewType) {
      return res.status(400).json({ success: false, message: 'Interview type and date/time are required.' });
    }

    const application = await Application.findById(req.params.id)
      .populate('user', 'name email')
      .populate('job');

    if (!application) {
      return res.status(404).json({ success: false, message: 'Application not found.' });
    }

    if (application.job.createdBy.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    const { sendInterviewInvite } = require('../utils/emailService');
    await sendInterviewInvite({
      seekerEmail: application.user.email,
      seekerName: application.user.name,
      jobTitle: application.job.title,
      companyName: application.job.company,
      interviewType,
      dateTime,
      location,
      meetingLink,
      contactPerson,
      additionalNotes,
    });

    res.json({ success: true, message: 'Interview invite sent successfully.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getMyPostedJobs, getJobApplicants, updateApplicantStatus, sendAptitudeTest, sendInterviewDetails };
