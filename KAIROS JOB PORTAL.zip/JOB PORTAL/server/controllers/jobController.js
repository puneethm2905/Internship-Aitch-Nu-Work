const Job = require('../models/Job');

const getJobs = async (req, res) => {
  try {
    const { search, category, type, location, experience, page = 1, limit = 12 } = req.query;

    const query = { isActive: true, isVerified: true };

    if (search) query.$text = { $search: search };
    if (category) query.category = category;
    if (type) query.type = type;
    if (location) query.location = new RegExp(location, 'i');
    if (experience) query.experience = experience;

    const total = await Job.countDocuments(query);
    const jobs = await Job.find(query)
      .populate('createdBy', 'name companyDetails')
      .sort({ createdAt: -1 })
      .skip((page - 1) * limit)
      .limit(Number(limit));

    res.json({ success: true, count: jobs.length, total, pages: Math.ceil(total / limit), jobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getJobById = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id).populate('createdBy', 'name email companyDetails');
    if (!job) return res.status(404).json({ success: false, message: 'Job listing not found.' });
    res.json({ success: true, job });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const createJob = async (req, res) => {
  try {
    if (req.user.role === 'seeker') {
      return res.status(403).json({ success: false, message: 'Seekers cannot post jobs.' });
    }

    const job = await Job.create({
      ...req.body,
      createdBy: req.user.id,
      isVerified: false,
    });

    res.status(201).json({ success: true, job });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const updateJob = async (req, res) => {
  try {
    let job = await Job.findById(req.params.id);

    if (!job) {
      return res.status(404).json({ success: false, message: 'Job not found.' });
    }

    if (job.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    job = await Job.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });

    res.json({ success: true, job });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const deleteJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);

    if (!job) {
      return res.status(404).json({ success: false, message: 'Job not found.' });
    }

    if (job.createdBy.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ success: false, message: 'Access denied.' });
    }

    await job.deleteOne();
    res.json({ success: true, message: 'Job listing deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getJobs, getJobById, createJob, updateJob, deleteJob };
