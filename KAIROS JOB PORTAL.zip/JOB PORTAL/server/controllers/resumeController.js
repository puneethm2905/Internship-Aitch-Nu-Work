const path = require('path');
const fs = require('fs');
const Resume = require('../models/Resume');

const uploadResume = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded.' });
    }

    const existing = await Resume.findOne({ user: req.user.id });
    if (existing) {
      const oldPath = path.join(__dirname, '../uploads', existing.filename);
      if (fs.existsSync(oldPath)) {
        try {
          fs.unlinkSync(oldPath);
        } catch (unlinkErr) {
          console.error('Old file cleanup failed:', unlinkErr.message);
        }
      }
    }

    const fileUrl = `/uploads/${req.file.filename}`;

    const resume = await Resume.findOneAndUpdate(
      { user: req.user.id },
      {
        user: req.user.id,
        filename: req.file.filename,
        originalName: req.file.originalname,
        fileUrl,
        mimetype: req.file.mimetype,
        size: req.file.size,
        uploadedAt: Date.now(),
      },
      { new: true, upsert: true }
    );

    res.json({ success: true, message: 'Resume uploaded successfully.', resume });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getMyResume = async (req, res) => {
  try {
    const resume = await Resume.findOne({ user: req.user.id });
    res.json({ success: true, resume });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { uploadResume, getMyResume };
