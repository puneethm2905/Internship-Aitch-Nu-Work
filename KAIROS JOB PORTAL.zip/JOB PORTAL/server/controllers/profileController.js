const path = require('path');
const fs = require('fs');
const Profile = require('../models/Profile');
const User = require('../models/User');

const getProfile = async (req, res) => {
  try {
    if (req.user.role === 'recruiter') {
      const user = await User.findById(req.user.id).select('name email phone companyDetails');
      return res.json({ success: true, profile: { user } });
    }

    const profile = await Profile.findOne({ user: req.user.id }).populate(
      'user',
      'name email phone avatar'
    );

    if (!profile) {
      return res.status(404).json({ success: false, message: 'Profile not found.' });
    }

    res.json({ success: true, profile });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const updateProfile = async (req, res) => {
  try {
    const { name, phone, bio, skills, education, experience, certificates, links, companyDetails } = req.body;

    const userUpdate = {};
    if (name) userUpdate.name = name;
    if (phone) userUpdate.phone = phone;

    if (req.user.role === 'recruiter' && companyDetails) {
      userUpdate.companyDetails = companyDetails;
    }

    await User.findByIdAndUpdate(req.user.id, userUpdate);

    if (req.user.role === 'seeker') {
      const profile = await Profile.findOneAndUpdate(
        { user: req.user.id },
        { bio, skills, education, experience, certificates, links, updatedAt: Date.now() },
        { new: true, upsert: true }
      ).populate('user', 'name email phone avatar');

      const completed = bio && skills?.length > 0 && education?.length > 0;
      if (completed) {
        await User.findByIdAndUpdate(req.user.id, { profileCompleted: true });
      }

      return res.json({ success: true, profile });
    }

    res.json({ success: true, message: 'Profile updated.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const uploadAvatar = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No image uploaded.' });
    }

    const user = await User.findById(req.user.id);

    if (user.avatar) {
      const oldPath = path.join(__dirname, '..', user.avatar.replace('/uploads', 'uploads'));
      if (fs.existsSync(oldPath)) {
        try { fs.unlinkSync(oldPath); } catch (e) {}
      }
    }

    const avatarUrl = `/uploads/avatars/${req.file.filename}`;
    await User.findByIdAndUpdate(req.user.id, { avatar: avatarUrl });

    res.json({ success: true, avatarUrl });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getProfile, updateProfile, uploadAvatar };
