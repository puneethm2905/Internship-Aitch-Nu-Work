const User = require('../models/User');
const Job = require('../models/Job');
const Application = require('../models/Application');
const Resume = require('../models/Resume');

const getStats = async (req, res) => {
  try {
    const [
      totalSeekers,
      totalRecruiters,
      totalJobs,
      totalApplications,
      activeJobs,
      pendingJobs,
      resumes,
    ] = await Promise.all([
      User.countDocuments({ role: 'seeker' }),
      User.countDocuments({ role: 'recruiter' }),
      Job.countDocuments(),
      Application.countDocuments(),
      Job.countDocuments({ isActive: true, isVerified: true }),
      Job.countDocuments({ isVerified: false }),
      Resume.countDocuments(),
    ]);

    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentApplications = await Application.countDocuments({
      appliedAt: { $gte: sevenDaysAgo },
    });

    res.json({
      success: true,
      stats: {
        totalSeekers,
        totalRecruiters,
        totalUsers: totalSeekers + totalRecruiters,
        totalJobs,
        totalApplications,
        activeJobs,
        pendingJobs,
        resumes,
        recentApplications,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getAllUsers = async (req, res) => {
  try {
    const { role } = req.query;
    const query = role ? { role } : { role: { $ne: 'admin' } };

    const users = await User.find(query).select('-password').sort({ createdAt: -1 });

    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getAllJobsAdmin = async (req, res) => {
  try {
    const jobs = await Job.find()
      .populate('createdBy', 'name email companyDetails')
      .sort({ createdAt: -1 });

    res.json({ success: true, jobs });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const verifyJob = async (req, res) => {
  try {
    const job = await Job.findById(req.params.id);

    if (!job) {
      return res.status(404).json({ success: false, message: 'Job not found.' });
    }

    job.isVerified = !job.isVerified;
    await job.save();

    res.json({
      success: true,
      message: `Job ${job.isVerified ? 'verified' : 'unverified'} successfully.`,
      job,
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const deleteUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    await User.findByIdAndDelete(req.params.id);

    res.json({ success: true, message: `${user.role} account deleted.` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { getStats, getAllUsers, getAllJobsAdmin, deleteUser, verifyJob };
