const Application = require('../models/Application');
const Job = require('../models/Job');
const Resume = require('../models/Resume');
const User = require('../models/User');
const { sendStatusEmail, sendApplicationConfirmation } = require('../utils/emailService');

const applyToJob = async (req, res) => {
  try {
    const { jobId, coverLetter } = req.body;

    const job = await Job.findById(jobId).populate('createdBy', 'email name');
    if (!job || !job.isActive) {
      return res.status(404).json({ success: false, message: 'Job listing is no longer active.' });
    }

    if (req.user.role !== 'seeker') {
      return res.status(403).json({ success: false, message: 'Only job seekers can submit applications.' });
    }

    const existing = await Application.findOne({ user: req.user.id, job: jobId });
    if (existing) {
      return res.status(400).json({ success: false, message: 'You have already applied for this role.' });
    }

    const resume = await Resume.findOne({ user: req.user.id });

    const application = await Application.create({
      user: req.user.id,
      job: jobId,
      coverLetter,
      resume: resume ? resume._id : null,
      status: 'applied',
    });

    await Job.findByIdAndUpdate(jobId, { $inc: { applicationsCount: 1 } });

    try {
      await sendApplicationConfirmation(
        req.user.email,
        job.createdBy?.email,
        job.title,
        req.user.name
      );
    } catch (emailErr) {
      console.error('Application confirmation email failed:', emailErr.message);
    }

    res.status(201).json({ success: true, application });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getMyApplications = async (req, res) => {
  try {
    const applications = await Application.find({ user: req.user.id })
      .populate('job', 'title company location type salary')
      .populate('resume', 'originalName fileUrl')
      .sort({ appliedAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const getAllApplications = async (req, res) => {
  try {
    const applications = await Application.find()
      .populate('user', 'name email phone')
      .populate('job', 'title company location')
      .populate('resume', 'originalName fileUrl')
      .sort({ appliedAt: -1 });

    res.json({ success: true, applications });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const updateStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const validStatuses = ['applied', 'under-review', 'shortlisted', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid status value.' });
    }

    const application = await Application.findById(req.params.id)
      .populate('user', 'name email')
      .populate('job');

    if (!application) {
      return res.status(404).json({ success: false, message: 'Application not found.' });
    }

    if (req.user.role !== 'admin' && application.job.createdBy.toString() !== req.user.id) {
      return res.status(403).json({ success: false, message: 'Unauthorized.' });
    }

    application.status = status;
    await application.save();

    try {
      await sendStatusEmail(
        application.user.email,
        status,
        application.job.title,
        application.job.company
      );
    } catch (emailErr) {
      console.error('Status email failed:', emailErr.message);
    }

    res.json({ success: true, message: `Status updated to ${status}.`, application });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { applyToJob, getMyApplications, getAllApplications, updateStatus };
