const path = require('path');
const fs = require('fs');
const Profile = require('../models/Profile');

const uploadCertificateFile = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, message: 'No file uploaded.' });
    }

    const fileUrl = `/uploads/certificates/${req.file.filename}`;

    res.json({
      success: true,
      fileUrl,
      filename: req.file.originalname,
      message: 'Certificate file uploaded.',
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

const deleteCertificateFile = async (req, res) => {
  try {
    const { filename } = req.params;

    if (!filename || filename.includes('..') || filename.includes('/')) {
      return res.status(400).json({ success: false, message: 'Invalid filename.' });
    }

    const filePath = path.join(__dirname, '../uploads/certificates', filename);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    res.json({ success: true, message: 'Certificate file deleted.' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

module.exports = { uploadCertificateFile, deleteCertificateFile };
