const express = require('express');
const router = express.Router();
const {
  getMyPostedJobs,
  getJobApplicants,
  updateApplicantStatus,
  sendAptitudeTest,
  sendInterviewDetails,
} = require('../controllers/recruiterController');
const { protect, recruiterOnly } = require('../middleware/auth');

router.use(protect, recruiterOnly);

router.get('/my-jobs', getMyPostedJobs);
router.get('/applications', getJobApplicants);
router.put('/applications/:id/status', updateApplicantStatus);
router.post('/applications/:id/send-test', sendAptitudeTest);
router.post('/applications/:id/send-interview', sendInterviewDetails);

module.exports = router;
