const express = require('express');
const router = express.Router();
const { getStats, getAllUsers, getAllJobsAdmin, deleteUser, verifyJob } = require('../controllers/adminController');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect, adminOnly);

router.get('/stats', getStats);
router.get('/users', getAllUsers);
router.get('/jobs', getAllJobsAdmin);
router.delete('/users/:id', deleteUser);
router.patch('/jobs/:id/verify', verifyJob);

module.exports = router;
