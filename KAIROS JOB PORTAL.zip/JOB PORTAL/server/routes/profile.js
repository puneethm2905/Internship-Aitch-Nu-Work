const express = require("express");
const router = express.Router();
const { getProfile, updateProfile, uploadAvatar } = require("../controllers/profileController");
const { protect } = require("../middleware/auth");
const uploadAvatarMiddleware = require("../middleware/uploadAvatar");

router.get("/", protect, getProfile);
router.put("/", protect, updateProfile);
router.post("/avatar", protect, uploadAvatarMiddleware.single("avatar"), uploadAvatar);

module.exports = router;
