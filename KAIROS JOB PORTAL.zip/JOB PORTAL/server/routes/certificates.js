const express = require('express');
const router = express.Router();
const { uploadCertificateFile, deleteCertificateFile } = require('../controllers/certificateController');
const { protect, seekerOnly } = require('../middleware/auth');
const uploadCertificate = require('../middleware/uploadCertificate');

router.post('/upload', protect, seekerOnly, uploadCertificate.single('certificate'), uploadCertificateFile);
router.delete('/file/:filename', protect, seekerOnly, deleteCertificateFile);

module.exports = router;
