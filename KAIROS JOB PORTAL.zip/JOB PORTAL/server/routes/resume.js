const express = require('express');
const router = express.Router();
const { uploadResume, getMyResume } = require('../controllers/resumeController');
const { protect, seekerOnly } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.post('/upload', protect, seekerOnly, upload.single('resume'), uploadResume);
router.get('/my', protect, seekerOnly, getMyResume);

module.exports = router;
