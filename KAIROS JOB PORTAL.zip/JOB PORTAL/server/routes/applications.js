const express = require('express');
const router = express.Router();
const { applyToJob, getMyApplications, getAllApplications, updateStatus } = require('../controllers/applicationController');
const { protect, recruiterOnly, seekerOnly, adminOnly } = require('../middleware/auth');

router.post('/', protect, seekerOnly, applyToJob);
router.get('/my', protect, seekerOnly, getMyApplications);
router.get('/all', protect, adminOnly, getAllApplications);
router.put('/:id/status', protect, recruiterOnly, updateStatus);

module.exports = router;
